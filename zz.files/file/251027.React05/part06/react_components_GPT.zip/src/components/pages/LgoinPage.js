import React from 'react';

const LgoinPage = () => {
  console.log("LgoinPage.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ LgoinPage.js ] 화면 준비중
    </div>
  );
};

export default LgoinPage;
