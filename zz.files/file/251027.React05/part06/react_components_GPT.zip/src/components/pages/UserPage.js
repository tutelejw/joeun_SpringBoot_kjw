import React from 'react';

const UserPage = () => {
  console.log("UserPage.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ UserPage.js ] 화면 준비중
    </div>
  );
};

export default UserPage;
