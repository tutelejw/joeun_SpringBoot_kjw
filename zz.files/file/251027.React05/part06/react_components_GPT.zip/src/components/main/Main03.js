import React from 'react';

const Main03 = () => {
  console.log("Main03.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ Main03.js ] 화면 준비중
    </div>
  );
};

export default Main03;
