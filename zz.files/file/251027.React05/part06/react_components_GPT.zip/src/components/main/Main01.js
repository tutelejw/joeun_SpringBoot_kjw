import React from 'react';

const Main01 = () => {
  console.log("Main01.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ Main01.js ] 화면 준비중
    </div>
  );
};

export default Main01;
