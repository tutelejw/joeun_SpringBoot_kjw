import React from 'react';

const LgoinForm = () => {
  console.log("LgoinForm.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ LgoinForm.js ] 화면 준비중
    </div>
  );
};

export default LgoinForm;
