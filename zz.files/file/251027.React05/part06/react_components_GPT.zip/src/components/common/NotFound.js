import React from 'react';

const NotFound = () => {
  console.log("NotFound.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ NotFound.js ] 화면 준비중
    </div>
  );
};

export default NotFound;
