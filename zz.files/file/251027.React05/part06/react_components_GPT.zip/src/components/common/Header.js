import React from 'react';

const Header = () => {
  console.log("Header.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      [ Header.js ] 화면 준비중
    </div>
  );
};

export default Header;
