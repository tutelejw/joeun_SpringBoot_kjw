import React from 'react';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import UserPage from './pages/UserPage';
import MainPage from './pages/01MainPage';
import LoginPage from './pages/01logonPage';
import NotFound from './components/common/NotFound';

const App01 = () => {
  console.log("01App.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      <Router>
        <Switch>
          <Route exact path="/" component={MainPage} />
          <Route path="/user" component={UserPage} />
          <Route path="/login" component={LoginPage} />
          <Route path="*" component={NotFound} />
        </Switch>
      </Router>
    </div>
  );
};

export default App01;
