import React from 'react';
import { Container, Row, Col } from 'react-bootstrap';
import Main01 from '../components/main/Main01';
import Main02 from '../components/main/Main02';
import Header from '../components/common/01Header';
import Footer from '../components/common/Footer';

const MainPage = () => {
  console.log("01MainPage.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      <Header />
      <Container style={{padding:'16px 0'}}>
        <Row>
          <Col lg={3}><Main01 /></Col>
          <Col lg={9}><Main02 /></Col>
        </Row>
      </Container>
      <Footer />
    </div>
  );
};

export default MainPage;
