import React from 'react';
import LoginForm from '../components/login/01LoginForm';

const LoginPage = () => {
  console.log("01logonPage.js 컴포넌트시작");
  return (
    <div className="ViewGood">
      <LoginForm />
    </div>
  );
};

export default LoginPage;
