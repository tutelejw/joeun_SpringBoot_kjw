import React from 'react';
const Footer = () => {
  console.log("Footer.js 컴포넌트시작");
  return (<div className="ViewGood">[ Footer.js ] 화면 준비중</div>);
};
export default Footer;