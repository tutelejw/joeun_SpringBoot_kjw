import React from 'react';
import { Link } from 'react-router-dom';

const Header01 = () => {
  console.log("01Header.js 컴포넌트시작");
  return (
    <div className="ViewGood" style={{padding:'12px 8px', borderBottom:'1px solid #eee'}}>
      <nav style={{display:'flex', gap:'12px'}}>
        <Link to="/">/</Link>
        <Link to="/user">/user</Link>
        <Link to="/login">/login</Link>
      </nav>
    </div>
  );
};

export default Header01;
