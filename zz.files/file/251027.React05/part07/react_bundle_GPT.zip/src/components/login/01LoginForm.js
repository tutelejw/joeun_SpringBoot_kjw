import React from 'react';

const LoginForm = () => {
  console.log("01LoginForm.js 컴포넌트시작");
  return (
    <div className="ViewGood" style={{display:'grid', placeItems:'center', minHeight:'60vh'}}>
      <form style={{minWidth:320, maxWidth:420, padding:20, border:'1px solid #ddd', borderRadius:8}}>
        <h3 style={{marginBottom:16}}>로그인</h3>
        <div style={{display:'grid', gap:12}}>
          <label>
            <div>userId</div>
            <input type="text" name="userId" className="form-control" />
          </label>
          <label>
            <div>password</div>
            <input type="password" name="password" className="form-control" />
          </label>
          <button type="submit" className="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  );
};

export default LoginForm;
