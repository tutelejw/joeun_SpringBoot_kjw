package example.app01uibase;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class UIBaseLayout09 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_uibaselayout09);
    }
}
