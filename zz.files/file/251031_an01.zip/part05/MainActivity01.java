package example.app00first;

import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

/*
 * ==> Android UI 구성	: 그림그리기(?)
 * 	1. Activity 생성 	: 	~ IS  A ~
 * 	2. Layout 생성		: 	new ~Layout()
 * 	3. View 생성		: 	new ~View()
 * 	4. Layout 에 View 올리기			: Layout.addView ()
 * 	5. Activity 에 Layout 올리기	: Activity.setContentView()
 */

//==> 각각의 API 를 반드시 확인
//==> 1. Activity 생성 	: 	~ IS  A ~
public class MainActivity01 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //EdgeToEdge.enable(this);

        ///////////////////////////////////////////////////////////////
        //setContentView(R.layout.activity_main);
        ///////////////////////////////////////////////////////////////

        ///////////////////////////////////////////////////////////////
        //2. Layout 생성		: 	new ~Layout() 	::
        LinearLayout linearLayout = new LinearLayout(this);

		//3. View 생성			: 	new ~View()
        TextView textView = new TextView(this);
        String message = "안녕, Hello Android!  Hard Coding";
        textView.setText(message);

        //4. Layout 에 View 올리기			: Layout.addView ()
        linearLayout.addView(textView);

        //5. Activity 에 Layout 올리기	: Activity.setContentView()
        setContentView(linearLayout);

        ///////////////////////////////////////////////////////////////

//        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
//            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
//            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
//            return insets;
//        });
    }
}