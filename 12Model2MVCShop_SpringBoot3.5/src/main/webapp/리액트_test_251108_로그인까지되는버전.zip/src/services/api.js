// File: src/services/api.js
import axios from 'axios';

// Axios 인스턴스 생성
// Spring Boot 서버가 8080 포트에서 실행 중이라고 가정합니다.
// (create-react-app의 3000번 포트와 다르므로 CORS 문제가 발생할 수 있습니다)
// **참고:** package.json에 "proxy": "http://localhost:8080" 를 추가하면 CORS를 우회할 수 있습니다.
const api = axios.create({
  baseURL: 'http://localhost:8080', // Spring Boot 서버 주소
  withCredentials: true, // Spring Session(JSESSIONID) 쿠키를 주고받기 위해 필수
});

// UserRestController.java의 /user/json/login (POST)
export const loginRequest = async (userId, password) => {
  const response = await api.post('/user/json/login', {
    userId: userId,
    password: password,
  });
  return response.data; // 컨트롤러가 반환하는 User 객체
};

// 로그아웃 요청 (Spring Security 등을 사용할 경우 세션 무효화)
// 여기서는 세션 관리를 브라우저 쿠키에 의존하므로,
// 클라이언트 측에서는 상태만 null로 변경합니다. (AuthContext 참조)
// 만약 서버에 /user/logout 엔드포인트가 있다면 호출합니다.
export const logoutRequest = async () => {
  // Spring Boot에 /user/logout 엔드포인트가 있다고 가정 (세션 무효화)
  try {
    await api.get('/user/logout'); // 예시 (GET 요청)
  } catch (error) {
    console.warn("Logout request to server failed, but logging out client-side.");
  }
};

// [수정] 'is not a function' 오류 해결을 위해
// 함수들을 객체로 묶어 default로 export합니다.
export default {
  loginRequest,
  logoutRequest
};