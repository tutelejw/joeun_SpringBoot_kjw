// File: src/pages/RegisterPage.js
import React from 'react';
import { Link } from 'react-router-dom';

// 회원가입 (addUser) 페이지 (placeholder)
// (UserRestController의 /user/json/addUser API와 연동될 페이지)
const RegisterPage = () => {
  return (
    <div className="jumbotron">
      <h1>회원가입</h1>
      <p>회원가입 폼이 여기에 표시됩니다.</p>
      {/* TODO: 회원가입 폼 구현 */}
      <p style={{ marginTop: '20px' }}>
        <Link to="/" className="btn btn-primary" style={{ textDecoration: 'none', color: 'white', background: '#007bff', padding: '10px 15px', borderRadius: '5px' }}>
          홈으로 돌아가기
        </Link>
      </p>
    </div>
  );
};

export default RegisterPage;