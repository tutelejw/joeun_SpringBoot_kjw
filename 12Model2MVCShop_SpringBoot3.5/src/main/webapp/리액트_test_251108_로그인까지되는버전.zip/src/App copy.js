// File: App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// 공통 컴포넌트
import Header from './components/common/Header';
import Footer from './components/common/Footer';
import ProtectedRoute from './components/common/ProtectedRoute';

// 페이지 컴포넌트
import IndexPage from './pages/IndexPage';
import LoginPage from './pages/LoginPage';
import MainPage from './pages/MainPage';
// TODO: 내 정보 페이지 (MyInfoPage) 등 추가

export default function App() {
  // 스타일 정의 (main.jsp의 padding-top: 70px 포함)
  const styles = `
    body {
      padding-top: 70px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    
    /* Bootstrap Jumbotron 스타일 흉내 */
    .jumbotron {
      padding: 2rem 1rem;
      margin-bottom: 2rem;
      background-color: #e9ecef;
      border-radius: 0.3rem;
    }
    
    .container {
      max-width: 960px;
      margin-right: auto;
      margin-left: auto;
      padding-right: 15px;
      padding-left: 15px;
    }

    /* Header 스타일 (Bootstrap navbar 흉내) */
    .app-header {
      background-color: #f8f9fa;
      border-bottom: 1px solid #e7e7e7;
      padding: 0.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1030;
      min-height: 50px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .app-header a {
      color: #007bff;
      text-decoration: none;
      padding: 0.5rem;
    }
    .app-header .brand {
      font-size: 1.25rem;
      font-weight: bold;
      color: #333;
    }
    .app-header nav a, .app-header nav button {
      margin-left: 10px;
      padding: 0.5rem 0.75rem;
      border: none;
      background: none;
      cursor: pointer;
      font-size: 1rem;
    }
    .app-header nav button {
      color: #007bff;
    }

    /* Footer 스타일 */
    .app-footer {
      text-align: center;
      padding: 1rem;
      margin-top: 2rem;
      background-color: #f8f9fa;
      border-top: 1px solid #e7e7e7;
      color: #6c757d;
    }
  `;

  return (
    // 1. AuthProvider로 앱 전체를 감싸 로그인 상태 공유
    <AuthProvider>
      <style>{styles}</style>
      {/* 2. BrowserRouter로 라우팅 활성화 */}
      <BrowserRouter>
        <Header />
        
        <main className="container">
          {/* 3. Routes로 페이지 경로 정의 */}
          <Routes>
            {/* 로그인 여부와 관계없이 접근 가능한 페이지
              index.jsp (로그인 전) -> IndexPage
              loginView.jsp -> LoginPage
            */}
            <Route path="/" element={<IndexPage />} />
            <Route path="/login" element={<LoginPage />} />

            {/* 로그인이 필요한 페이지 (index.jsp에서 로그인 시 main.jsp로 forward)
              ProtectedRoute가 LogonCheckInterceptor 역할을 함
            */}
            <Route
              path="/main"
              element={
                <ProtectedRoute>
                  <MainPage />
                </ProtectedRoute>
              }
            />
            {/* TODO: 내 정보 페이지 라우트
            <Route
              path="/user/my-info"
              element={
                <ProtectedRoute>
                  <MyInfoPage />
                </ProtectedRoute>
              }
            />
            */}

          </Routes>
        </main>
        
        <Footer />
      </BrowserRouter>
    </AuthProvider>
  );
}