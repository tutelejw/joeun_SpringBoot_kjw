// File: src/App.js
import React, { useState, useEffect } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
// [수정] .js 확장자 명시
import { AuthProvider } from './context/AuthContext.js';

// 공통 컴포넌트
import Header from './components/common/Header.js';
import Footer from './components/common/Footer.js';
import ProtectedRoute from './components/common/ProtectedRoute.js';

// 페이지 컴포넌트
import IndexPage from './pages/IndexPage.js';
import LoginPage from './pages/LoginPage.js';
import MainPage from './pages/MainPage.js';
import RegisterPage from './pages/RegisterPage.js';
import MyInfoPage from './pages/MyInfoPage.js';
import UserListPage from './pages/UserListPage.js';
import AddProductPage from './pages/AddProductPage.js';
import ProductListPage from './pages/ProductListPage.js';
import ProductManagePage from './pages/ProductManagePage.js';
import ProductDetailPage from './pages/ProductDetailPage.js';
import ProductUpdatePage from './pages/ProductUpdatePage.js';
import PurchaseListPage from './pages/PurchaseListPage.js';

export default function App() {
  // 스플래시 화면 상태 관리
  const [showSplash, setShowSplash] = useState(true);

  // 컴포넌트 마운트 시 스플래시 화면 타이머 설정
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowSplash(false);
    }, 2500); // 2.5초 후 스플래시 화면 제거

    return () => clearTimeout(timer);
  }, []);

  // 스타일 정의
  const styles = `
    /* [수정] 모든 요소가 padding, border를 너비에 포함하도록 설정 */
    *, *::before, *::after {
      box-sizing: border-box;
    }

    body {
      padding-top: 70px; /* 헤더 높이만큼 패딩 */
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }

    /* 스플래시 화면 스타일 */
    .splash-screen {
      position: fixed;
      inset: 0;
      background-color: white;
      display: flex;
      align-items: center;
      justify-content: center;
      z-index: 9999;
      animation: fadeOutSplashScreen 2.5s ease-in-out forwards;
    }

    .splash-logo {
      font-size: 3.5rem;
      font-weight: 600;
      color: #4F46E5;
      letter-spacing: -0.02em;
      animation: zoomInLogo 2.2s ease-in-out forwards;
    }

    @media (min-width: 768px) {
      .splash-logo {
        font-size: 5rem;
      }
    }

    @keyframes zoomInLogo {
      0% {
        transform: scale(0.5);
        opacity: 0;
      }
      50% {
        transform: scale(1.2);
        opacity: 1;
      }
      100% {
        transform: scale(1);
        opacity: 1;
      }
    }

    @keyframes fadeOutSplashScreen {
      0%, 80% {
        opacity: 1;
        visibility: visible;
      }
      100% {
        opacity: 0;
        visibility: hidden;
      }
    }
    
    .jumbotron {
      padding: 2rem 1rem;
      margin-bottom: 2rem;
      background-color: #e9ecef;
      border-radius: 0.3rem;
    }
    
    .container {
      max-width: 960px;
      margin-right: auto;
      margin-left: auto;
      padding-right: 15px;
      padding-left: 15px;
    }

    /* index.jsp의 2단 레이아웃 스타일 */
    .index-layout-row {
      display: flex;
      flex-wrap: wrap;
      margin-right: -15px;
      margin-left: -15px;
    }
    .index-menu-col {
      position: relative;
      padding-right: 15px;
      padding-left: 15px;
      /* [수정] 항상 25%를 차지하도록 고정 (col-md-3) */
      flex: 0 0 25%;
      max-width: 25%;
    }
    .index-main-col {
      position: relative;
      padding-right: 15px;
      padding-left: 15px;
      /* [수정] 항상 75%를 차지하도록 고정 (col-md-9) */
      flex: 0 0 75%;
      max-width: 75%;
    }

    /* Bootstrap Panel 스타일 흉내 */
    .panel {
      margin-bottom: 20px;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
    .panel-primary {
      border-color: #337ab7;
    }
    .panel-heading {
      color: #fff;
      background-color: #337ab7;
      border-color: #337ab7;
      padding: 10px 15px;
      border-bottom: 1px solid transparent;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    .list-group {
      padding-left: 0;
      margin-bottom: 0;
    }
    .list-group-item {
      position: relative;
      display: block;
      padding: 10px 15px;
      margin-bottom: -1px;
      background-color: #fff;
      border: 1px solid #ddd;
    }
    .list-group-item:first-child {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
    }
    .list-group-item:last-child {
      margin-bottom: 0;
      border-bottom-right-radius: 3px;
      border-bottom-left-radius: 3px;
    }
    .list-group-item a {
      color: #337ab7;
      text-decoration: none;
    }

    /* Header 스타일 (Bootstrap navbar 흉내) */
    .app-header {
      background-color: #f8f9fa;
      border-bottom: 1px solid #e7e7e7;
      padding: 0.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1030;
      min-height: 50px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .app-header .brand {
      font-size: 1.25rem;
      font-weight: bold;
      color: #333;
    }
    
    /* [수정] 헤더 nav 태그 */
    .app-header nav {
      display: flex;
      align-items: center;
    }

    .app-header nav a, .app-header nav button {
      margin-left: 10px;
      padding: 0.5rem 0.75rem;
      border: none;
      background: none;
      cursor: pointer;
      font-size: 1rem;
    }
    .app-header nav button {
      color: #007bff;
    }

    /* 드롭다운 메뉴 스타일 */
    .dropdown {
      position: relative;
      display: inline-block;
      margin-left: 10px;
    }
    .dropdown-toggle {
      background: none;
      border: none;
      padding: 0.5rem 0.75rem;
      font-size: 1rem;
      color: #333;
      cursor: pointer;
    }
    .dropdown-toggle:hover {
      background-color: #f0f0f0;
    }
    .dropdown-menu {
      position: absolute;
      top: 100%;
      left: 0;
      z-index: 1000;
      display: block;
      min-width: 160px;
      padding: 5px 0;
      margin: 2px 0 0;
      font-size: 1rem;
      text-align: left;
      list-style: none;
      background-color: #fff;
      background-clip: padding-box;
      border: 1px solid rgba(0,0,0,.15);
      border-radius: 4px;
      box-shadow: 0 6px 12px rgba(0,0,0,.175);
    }
    .dropdown-menu a {
      display: block;
      padding: 3px 20px;
      clear: both;
      font-weight: 400;
      line-height: 1.42857143;
      color: #333;
      white-space: nowrap;
      text-decoration: none;
    }
    .dropdown-menu a:hover {
      color: #262626;
      background-color: #f5f5f5;
    }

    /* Footer 스타일 */
    .app-footer {
      text-align: center;
      padding: 1rem;
      margin-top: 2rem;
      background-color: #f8f9fa;
      border-top: 1px solid #e7e7e7;
      color: #6c757d;
    }
  `;

  return (
    <AuthProvider>
      <style>{styles}</style>
      
      {/* 스플래시 화면 */}
      {showSplash && (
        <div className="splash-screen">
          <h1 className="splash-logo">MyWebApp</h1>
        </div>
      )}

      <BrowserRouter>
        <Header />
        <main className="container">
          <Routes>
            {/* 공용 페이지 */}
            <Route path="/" element={<ProductListPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            
            {/* 상품 검색 페이지 (로그인 불필요) */}
            <Route path="/product/listProduct/search" element={<ProductListPage />} />

            {/* 로그인 필요 페이지 */}
            <Route path="/main" element={<ProtectedRoute><MainPage /></ProtectedRoute>} />
           
            {/* 회원관리 */}
            <Route path="/user/getUser/:userId" element={<ProtectedRoute><MyInfoPage /></ProtectedRoute>} />
            <Route path="/user/listUser" element={<ProtectedRoute><UserListPage /></ProtectedRoute>} />
            
            {/* 상품관리(admin 전용) */}
            <Route path="/product/addProduct" element={<ProtectedRoute><AddProductPage /></ProtectedRoute>} />
            <Route path="/product/listProduct/manage" element={<ProtectedRoute><ProductManagePage /></ProtectedRoute>} />
            <Route path="/product/updateProduct/:prodNo" element={<ProtectedRoute><ProductUpdatePage /></ProtectedRoute>} />
            <Route path="/product/getProduct/:prodNo" element={<ProductDetailPage />} />
            
            {/* 구매관리 (User 전용) */}
            <Route path="/purchase/listPurchase" element={<ProtectedRoute><PurchaseListPage /></ProtectedRoute>} />
          </Routes>
        </main>
        <Footer />
      </BrowserRouter>
    </AuthProvider>
  );
}