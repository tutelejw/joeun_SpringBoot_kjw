// src/pages/ProductDetailPage.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const ProductDetailPage = () => {
  const { prodNo } = useParams();
  const navigate = useNavigate();

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get(`/product/json/getProduct/${prodNo}`, { withCredentials: true });
        setProduct(res.data);
      } catch (err) {
        console.error(err);
        setError('상품 정보를 불러오는데 실패했습니다.');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [prodNo]);

  const handlePurchase = () => {
    navigate(`/purchase/addPurchaseView?prodNo=${prodNo}`);
  };

  const handleConfirm = () => {
    navigate(-1);
  };

  if (loading) return <div className="container"><p>로딩 중...</p></div>;
  if (error) return <div className="container"><p style={{color: 'red'}}>{error}</p></div>;
  if (!product) return <div className="container"><p>상품 정보를 찾을 수 없습니다.</p></div>;

  return (
    <div className="container" style={{ paddingTop: '50px' }}>
      <h2>상품정보조회</h2>
      <table className="table table-bordered" style={{ maxWidth: '600px' }}>
        <tbody>
          <tr>
            <th>상품번호</th>
            <td>{product.prodNo}</td>
          </tr>
          <tr>
            <th>상품명</th>
            <td>{product.prodName}</td>
          </tr>
          <tr>
            <th>상품 이미지</th>
            <td>
              {product.fileName ? (
                <>
                  <img
                    src={`/images/${product.fileName}`}
                    alt="상품 이미지"
                    style={{ maxWidth: '320px', maxHeight: '320px' }}
                    className="product-image"
                  />
                  <br />
                  <small>{product.fileName}</small>
                </>
              ) : (
                <span>이미지 없음</span>
              )}
            </td>
          </tr>
          <tr>
            <th>상품 상세정보</th>
            <td>{product.prodDetail}</td>
          </tr>
          <tr>
            <th>제조일자</th>
            <td>{product.manuDate}</td>
          </tr>
          <tr>
            <th>가격</th>
            <td>{product.price?.toLocaleString()} 원</td>
          </tr>
          <tr>
            <th>등록일자</th>
            <td>{product.regDate}</td>
          </tr>
        </tbody>
      </table>

      <div style={{ maxWidth: '600px', marginTop: '20px', display: 'flex', justifyContent: 'flex-end', gap: '10px' }}>
        <button className="btn btn-primary" onClick={handlePurchase}>
          구매
        </button>
        <button className="btn btn-secondary" onClick={handleConfirm}>
          확인
        </button>
      </div>
    </div>
  );
};

export default ProductDetailPage;
