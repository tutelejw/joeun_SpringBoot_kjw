// File: src/pages/LoginPage.js
import React, { useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
// [수정] .js 확장자 제거
import { useAuth } from '../hooks/useAuth';

// loginView.jsp를 대체하는 LoginPage
const LoginPage = () => {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(''); // 로그인 실패 메시지
  const { login, loading } = useAuth(); // AuthContext에서 login 함수 가져오기
  
  const navigate = useNavigate();
  const location = useLocation();
  // ProtectedRoute에서 넘겨준 'from' 정보 (로그인 후 돌아갈 페이지)
  const from = location.state?.from?.pathname || '/main';

  const handleSubmit = async (e) => {
    e.preventDefault(); // form의 기본 제출 동작(새로고침) 방지
    setError('');

    if (!userId || !password) {
      setError('아이디와 비밀번호를 모두 입력해주세요.');
      return;
    }

    try {
      await login(userId, password);
      // 로그인 성공 시, 원래 가려던 페이지(from) 또는 /main으로 이동
      navigate(from, { replace: true });
    } catch (err) {
      console.error(err);
      setError(err.message || '로그인에 실패했습니다.');
    }
  };

  // loginView.jsp의 폼 스타일 흉내
  const formStyle = {
    maxWidth: '400px',
    margin: '0 auto',
    padding: '2rem',
    border: '1px solid #ddd',
    borderRadius: '8px',
    backgroundColor: '#f9f9f9',
  };
  const inputStyle = {
    width: '100%',
    padding: '0.75rem',
    margin: '0.5rem 0 1rem 0',
    borderRadius: '4px',
    border: '1px solid #ccc',
    boxSizing: 'border-box', // padding이 width에 포함되도록
  };
  const buttonStyle = {
    width: '100%',
    padding: '0.75rem',
    backgroundColor: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '1rem',
  };
  const errorStyle = {
    color: 'red',
    marginBottom: '1rem',
    textAlign: 'center',
  };

  return (
    <div className="jumbotron">
      <form onSubmit={handleSubmit} style={formStyle}>
        <h1 style={{ textAlign: 'center' }}>로 그 인</h1>
        
        <label htmlFor="userId">아 이 디</label>
        <input
          type="text"
          id="userId"
          value={userId}
          onChange={(e) => setUserId(e.target.value)}
          placeholder="아이디"
          style={inputStyle}
        />
        
        <label htmlFor="password">패 스 워 드</label>
        <input
          type="password"
          id="password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="패스워드"
          style={inputStyle}
        />
        
        {error && <div style={errorStyle}>{error}</div>}
        
        <button type="submit" style={buttonStyle} disabled={loading}>
          {loading ? '로그인 중...' : '로 그 인'}
        </button>
        {/* TODO: 회원가입 버튼 */}
        {/* <button type="button" onClick={() => navigate('/register')} style={{...buttonStyle, marginTop: '10px', backgroundColor: '#6c757d'}}>
          회 원 가 입
        </button> */}
      </form>
    </div>
  );
};

export default LoginPage;