// File: src/pages/IndexPage.js
import React from 'react';
import { Link } from 'react-router-dom';
// import { useAuth } from '../hooks/useAuth.js'; // useAuth는 이 페이지에서 사용되지 않네요.

// index.jsp (로그인 전)를 대체하는 페이지
const IndexPage = () => {
  const buttonStyle = {
    display: 'inline-block',
    padding: '0.6rem 1.2rem',
    border: 'none',
    background: '#007bff',
    color: 'white',
    borderRadius: '5px',
    cursor: 'pointer',
    fontWeight: 'bold',
    textDecoration: 'none',
    margin: '0 5px',
  };

  // JSP의 링크 스타일 흉내
  const menuLinkStyle = {
    color: '#337ab7',
    textDecoration: 'none',
  };

  // 로그인 전이라 비활성화된 링크 스타일
  const disabledMenuLinkStyle = {
    color: '#777',
    textDecoration: 'none',
    pointerEvents: 'none', // 클릭 비활성화
    cursor: 'default',
  };

  return (
    <div className="index-layout-row"> {/* index.jsp의 <div class="row"> */}
      
      {/* Menu 구성 (index.jsp의 col-md-3) */}
      <div className="index-menu-col">
        
        <div className="panel panel-primary">
          <div className="panel-heading">
            회원관리
          </div>
          <ul className="list-group">
            <li className="list-group-item">
              <a href="#" style={disabledMenuLinkStyle}>개인정보조회</a>
            </li>
            <li className="list-group-item">
              <a href="#" style={disabledMenuLinkStyle}>회원정보조회</a>
            </li>
          </ul>
        </div>

        <div className="panel panel-primary">
          <div className="panel-heading">
            판매상품관리
          </div>
          <ul className="list-group">
            <li className="list-group-item">
              <a href="#" style={disabledMenuLinkStyle}>판매상품등록</a>
            </li>
            <li className="list-group-item">
              <a href="#" style={disabledMenuLinkStyle}>판매상품관리</a>
            </li>
          </ul>
        </div>

        <div className="panel panel-primary">
          <div className="panel-heading">
            상품구매
          </div>
          <ul className="list-group">
            <li className="list-group-item">
              {/* 상품검색은 로그인 전에도 가능하다고 가정 */}
              <a href="#" style={menuLinkStyle}>상품검색</a>
            </li>
            <li className="list-group-item">
              <a href="#" style={disabledMenuLinkStyle}>구매이력조회</a>
            </li>
            <li className="list-group-item">
              <a href="#" style={disabledMenuLinkStyle}>최근본상품</a>
            </li>
          </ul>
        </div>

      </div>

      {/* Main Jumbotron (index.jsp의 col-md-9) */}
      <div className="index-main-col">
        <div className="jumbotron">
          <h1>Model2 MVC Shop</h1>
          <p>로그인 후 사용가능...</p>
          <p>로그인 전 검색만 가능합니다.</p>
          <p>회원가입 하세요.</p>
          
          <div style={{ textAlign: 'center', marginTop: '20px' }}>
            {/* 회원가입 버튼. /user/addUser 로의 이동은 App.js 라우터에 추가 필요 */}
            {/* <Link to="/register" style={buttonStyle}>회원가입</Link> */}
            <a href="/user/addUser" style={buttonStyle} onClick={(e) => { e.preventDefault(); alert('회원가입 페이지로 이동합니다. (라우터 설정 필요)'); }}>회원가입</a>
            <Link to="/login" style={buttonStyle}>로 그 인</Link>
          </div>
        </div>
      </div>

    </div>
  );
};

export default IndexPage;