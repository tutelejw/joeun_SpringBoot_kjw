// File: src/pages/PurchaseListPage.js
// 경로: /purchase/listPurchase (User 전용)
import React from 'react';
// [수정] .js 확장자 명시
import { useAuth } from '../hooks/useAuth.js';
import { Navigate } from 'react-router-dom';

const PurchaseListPage = () => {
  const { user } = useAuth();

  // 'user'가 아니면 /main으로 리다이렉트 (admin은 구매이력 X)
  if (user.role !== 'user') {
    return <Navigate to="/main" replace />;
  }

  return (
    <div className="jumbotron">
      <h1>구매이력조회</h1>
      <p>이곳에 {user.userName}님의 구매 이력이 표시됩니다.</p>
    </div>
  );
};

export default PurchaseListPage;