// File: src/components/common/Header.js
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
// [수정] .js 확장자 명시
import { useAuth } from '../../hooks/useAuth.js';

// Dropdown 컴포넌트 추가
const Dropdown = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef(null); // 드롭다운 DOM을 참조

  // 드롭다운 영역 밖을 클릭하면 닫히도록 하는 Hook
  useEffect(() => {
    const handleClickOutside = (event) => {
      // ref.current(드롭다운)가 존재하고, 클릭한 곳이 드롭다운 외부일 때
      if (ref.current && !ref.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    // mousedown 이벤트로 감지
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      // 컴포넌트 unmount 시 이벤트 리스너 제거
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [ref]); // ref가 변경될 때만 실행

  return (
    <div className="dropdown" ref={ref}> {/* ref 할당 */}
      <button 
        className="dropdown-toggle" 
        onClick={() => setIsOpen(!isOpen)} // 클릭하면 토글
      >
        {title} <span className="caret">▼</span>
      </button>
      
      {isOpen && (
        <div className="dropdown-menu">
          {/* 자식으로 전달된 Link들을 렌더링
            map을 돌면서 onClick을 추가하여, 링크 클릭 시 메뉴가 닫히도록 함
          */}
          {React.Children.map(children, (child) => 
            React.cloneElement(child, { 
              onClick: () => {
                setIsOpen(false); // 링크 클릭 시 메뉴 닫기
                if(child.props.onClick) child.props.onClick();
              }
            })
          )}
        </div>
      )}
    </div>
  );
};


// toolbar.jsp를 대체하는 Header 컴포넌트
const Header = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/'); // 로그아웃 후 홈으로 이동
  };

  return (
    <header className="app-header">
      <Link to={user ? "/main" : "/"} className="brand">
        Model2 MVC Shop
      </Link>
      
      <nav>
        {user ? (
          // 로그인 상태 (main.jsp의 toolbar) [수정됨]
          <>
            {/* 1. 회원관리 드롭다운 */}
            <Dropdown title="회원관리">
              {/* toolbar.jsp: /user/getUser?userId=${sessionScope.user.userId} */}
              <Link to={`/user/getUser/${user.userId}`}>개인정보조회</Link>
              
              {user.role === 'admin' && (
                /* toolbar.jsp: /user/listUser */
                <Link to="/user/listUser">회원정보조회</Link>
              )}
            </Dropdown>

            {/* 2. 판매상품관리 드롭다운 (admin only) */}
            {user.role === 'admin' && (
              <Dropdown title="판매상품관리">
                {/* toolbar.jsp: 판매상품등록 (경로 가정) */}
                <Link to="/product/addProduct">판매상품등록</Link>
                {/* toolbar.jsp: /product/listProduct?menu=manage */}
                <Link to="/product/listProduct/manage">판매상품관리</Link>
              </Dropdown>
            )}
            
            {/* 3. 상품구매 드롭다운 */}
            <Dropdown title="상품구매">
              {/* toolbar.jsp: /product/listProduct?menu=search */}
              <Link to="/product/listProduct/search">상 품 검 색</Link>
              
              {user.role === 'user' && (
                /* toolbar.jsp: 구매이력조회 (경로 가정) */
                <Link to="/purchase/listPurchase">구매이력조회</Link>
              )}
              
              {/* <Link to="#">최근본상품</Link> */}
            </Dropdown>

            {/* 환영 메시지 및 로그아웃 버튼 */}
            <span style={{marginLeft: '15px', color: '#333'}}>{user.userName}님</span>
            <button onClick={handleLogout} style={{marginLeft: '15px'}}>로그아웃</button>
          </>
        ) : (
          // 비로그인 상태 (index.jsp의 toolbar)
          <>
            <Link to="/register">회원가입</Link>
            <Link to="/login">로 그 인</Link>
          </>
        )}
      </nav>
    </header>
  );
};

export default Header;