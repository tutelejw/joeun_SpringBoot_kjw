import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../hooks/useAuth';

// Dropdown 컴포넌트: 바깥 클릭 시 메뉴 닫기 기능 포함
const Dropdown = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (ref.current && !ref.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [ref]);

  return (
    <div className="dropdown" ref={ref}>
      <button 
        className="dropdown-toggle" 
        onClick={() => setIsOpen(!isOpen)}
      >
        {title} <span className="caret">▼</span>
      </button>
      
      {isOpen && (
        <div className="dropdown-menu">
          {React.Children.toArray(children) // children을 배열로 변환 후
            .filter(Boolean)                // false, null 제거
            .map((child) => 
              React.cloneElement(child, { 
                onClick: () => {
                  setIsOpen(false); // 메뉴 닫기
                  if(child.props.onClick) child.props.onClick();
                }
              })
          )}
        </div>
      )}
    </div>
  );
};


// 헤더 컴포넌트 (관리자 및 사용자 메뉴 포함)
const Header = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="app-header">
      <Link to={user ? "/main" : "/"} className="brand">
        Model2 MVC Shop
      </Link>
      
      <nav>
        {user ? (
          <>
            {/* 회원관리 드롭다운 */}
            <Dropdown title="회원관리">
              <Link to={`/user/getUser/${user.userId}`}>개인정보조회</Link>
              {user.role === 'admin' && (
                <Link to="/user/listUser">회원정보조회</Link>
              )}
            </Dropdown>

            {/* 판매상품관리 드롭다운 (관리자 전용) */}
            {user.role === 'admin' && (
              <Dropdown title="판매상품관리">
                <Link to="/product/addProduct">판매상품등록</Link>
                <Link to="/product/listProduct/manage">판매상품관리</Link>
              </Dropdown>
            )}
            
            {/* 상품구매 드롭다운 */}
            <Dropdown title="상품구매">
              <Link to="/product/listProduct/search">상 품 검 색</Link>
              {user.role === 'user' && (
                <Link to="/purchase/listPurchase">구매이력조회</Link>
              )}
            </Dropdown>

            {/* 환영 메시지 및 로그아웃 버튼 */}
            <span style={{marginLeft: '15px', color: '#333'}}>
              {user.userName}님
            </span>
            <button onClick={handleLogout} style={{marginLeft: '15px'}}>
              로그아웃
            </button>
          </>
        ) : (
          <>
            <Link to="/register">회원가입</Link>
            <Link to="/login">로 그 인</Link>
          </>
        )}
      </nav>
    </header>
  );
};

export default Header;
