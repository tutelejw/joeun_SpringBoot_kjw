// File: src/components/common/Header.js
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
// [수정] .js 확장자 제거
import { useAuth } from '../../hooks/useAuth';

// Dropdown 컴포넌트 추가
const Dropdown = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef(null);

  // ... (useEffect 밖 클릭 시 닫기 로직은 동일) ...
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (ref.current && !ref.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [ref]);

  return (
    <div className="dropdown" ref={ref}>
      <button 
        className="dropdown-toggle" 
        onClick={() => setIsOpen(!isOpen)}
      >
        {title} <span className="caret">▼</span>
      </button>
      
      {isOpen && (
        <div className="dropdown-menu">
          {/* [BUG FIX]
            React.Children.map을 사용하기 전에 children을 필터링합니다.
            'user.role === 'admin' && <Link ...>'와 같은 구문은
            user.role이 'admin'이 아닐 때 'false'를 반환합니다.
            React.cloneElement(false, ...)는 "must be a React element" 오류를 발생시킵니다.
            React.Children.toArray로 'false', 'null' 값들을 배열에서 제거합니다.
          */}
          {React.Children.toArray(children) // 1. children을 배열로 만들고
            .filter(Boolean) // 2. false, null, undefined 등 유효하지 않은 요소를 제거
            .map((child) => // 3. 유효한 React 요소만 map으로 순회
              React.cloneElement(child, { 
                onClick: () => {
                  setIsOpen(false); // 링크 클릭 시 메뉴 닫기
                  if(child.props.onClick) child.props.onClick();
                }
              })
          )}
        </div>
      )}
    </div>
  );
};


// toolbar.jsp를 대체하는 Header 컴포넌트
const Header = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <header className="app-header">
      <Link to={user ? "/main" : "/"} className="brand">
        Model2 MVC Shop
      </Link>
      
      <nav>
        {user ? (
          // 로그인 상태 (main.jsp의 toolbar)
          <>
            {/* 1. 회원관리 드롭다운 */}
            <Dropdown title="회원관리">
              <Link to={`/user/getUser/${user.userId}`}>개인정보조회</Link>
              
              {user.role === 'admin' && (
                <Link to="/user/listUser">회원정보조회</Link>
              )}
            </Dropdown>

            {/* 2. 판매상품관리 드롭다운 (admin only) */}
            {user.role === 'admin' && (
              <Dropdown title="판매상품관리">
                <Link to="/product/addProduct">판매상품등록</Link>
                <Link to="/product/listProduct/manage">판매상품관리</Link>
              </Dropdown>
            )}
            
            {/* 3. 상품구매 드롭다운 */}
            <Dropdown title="상품구매">
              <Link to="/product/listProduct/search">상 품 검 색</Link>
              
              {user.role === 'user' && (
                <Link to="/purchase/listPurchase">구매이력조회</Link>
              )}
              
              {/* <Link to="#">최근본상품</Link> */}
            </Dropdown>

            {/* 환영 메시지 및 로그아웃 버튼 */}
            <span style={{marginLeft: '15px', color: '#333'}}>{user.userName}님</span>
            <button onClick={handleLogout} style={{marginLeft: '15px'}}>로그아웃</button>
          </>
        ) : (
          // 비로그인 상태 (index.jsp의 toolbar)
          <>
            <Link to="/register">회원가입</Link>
            <Link to="/login">로 그 인</Link>
          </>
        )}
      </nav>
    </header>
  );
};

export default Header;