// File: src/hooks/useAuth.js
import { useContext } from 'react';
// [수정] .js 확장자 추가
import { AuthContext } from '../context/AuthContext.js';

// 매번 useContext(AuthContext)를 쓰는 대신
// useAuth() 훅을 만들어 편하게 사용
const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export { useAuth }; // named export로 변경