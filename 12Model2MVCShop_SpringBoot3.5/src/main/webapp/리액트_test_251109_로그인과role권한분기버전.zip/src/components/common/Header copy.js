// File: src/components/common/Header.js
import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
// [수정] .js 확장자 제거
import { useAuth } from '../../hooks/useAuth';

// toolbar.jsp를 대체하는 Header 컴포넌트
const Header = () => {
  const { user, logout } = useAuth(); // AuthContext에서 user 정보와 logout 함수 가져오기
  const navigate = useNavigate();

  const handleLogout = async () => {
    await logout();
    navigate('/'); // 로그아웃 후 홈으로 이동
  };

  return (
    <header className="app-header">
      {/* toolbar.jsp의 navbar-brand */}
      <Link to={user ? "/main" : "/"} className="brand">
        Model2 MVC Shop
      </Link>
      
      {/* toolbar.jsp의 로그인/로그아웃 링크 (JSTL c:if 대체) */}
      <nav>
        {user ? (
          // 로그인 상태 (main.jsp의 toolbar)
          <>
            <span>{user.userName}님 환영합니다.</span>
            {/* TODO: '내 정보' 링크 (toolbar.jsp의 '개인정보조회') */}
            {/* <Link to={`/user/getUser?userId=${user.userId}`}>내 정보</Link> */}
            
            {/* 관리자(admin)일 경우 */}
            {user.role === 'admin' && (
              <>
                {/* <Link to="/admin/user-list">회원정보조회</Link> */}
                {/* <Link to="/admin/product-manage">판매상품관리</Link> */}
              </>
            )}

            <button onClick={handleLogout}>로그아웃</button>
          </>
        ) : (
          // 비로그인 상태 (index.jsp의 toolbar)
          <>
            <Link to="/register">회원가입</Link> {/* [수정] 주석 해제 및 경로 변경 */}
            <Link to="/login">로 그 인</Link>
          </>
        )}
      </nav>
    </header>
  );
};

export default Header;