// File: App.js
import React from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext.js'; // .js 확장자 추가

// 공통 컴포넌트
import Header from './components/common/Header.js'; // .js 확장자 추가
import Footer from './components/common/Footer.js'; // .js 확장자 추가
import ProtectedRoute from './components/common/ProtectedRoute.js'; // .js 확장자 추가

// 페이지 컴포넌트
import IndexPage from './pages/IndexPage.js'; // .js 확장자 추가
import LoginPage from './pages/LoginPage.js'; // .js 확장자 추가
import MainPage from './pages/MainPage.js'; // .js 확장자 추가
import RegisterPage from './pages/RegisterPage.js'; // .js 확장자 추가
// TODO: 내 정보 페이지 (MyInfoPage) 등 추가

export default function App() {
  // 스타일 정의 (main.jsp의 padding-top: 70px 포함)
  const styles = `
    /* [수정] 모든 요소가 padding, border를 너비에 포함하도록 설정 */
    *, *::before, *::after {
      box-sizing: border-box;
    }

    body {
      padding-top: 70px;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
    }
    
    /* Bootstrap Jumbotron 스타일 흉내 */
    .jumbotron {
      padding: 2rem 1rem;
      margin-bottom: 2rem;
      background-color: #e9ecef;
      border-radius: 0.3rem;
    }
    
    .container {
      max-width: 960px;
      margin-right: auto;
      margin-left: auto;
      padding-right: 15px;
      padding-left: 15px;
    }

    /* index.jsp의 2단 레이아웃 스타일 */
    .index-layout-row {
      display: flex;
      flex-wrap: wrap;
      margin-right: -15px;
      margin-left: -15px;
    }
    .index-menu-col {
      position: relative;
      /* width: 100%; (제거) */
      padding-right: 15px;
      padding-left: 15px;
      /* 기본(모바일)에서는 100% 너비 (제거) */
      
      /* [수정] 항상 25%를 차지하도록 고정 */
      flex: 0 0 25%; /* col-md-3 */
      max-width: 25%;
    }
    .index-main-col {
      position: relative;
      /* width: 100%; (제거) */
      padding-right: 15px;
      padding-left: 15px;
      /* 기본(모바일)에서는 100% 너비 (제거) */

      /* [수정] 항상 75%를 차지하도록 고정 */
      flex: 0 0 75%; /* col-md-9 */
      max-width: 75%;
    }

    /* * [삭제] 반응형 미디어 쿼리 블록
     * @media (min-width: 768px) { ... }
     */

    /* Bootstrap Panel 스타일 흉내 */
    .panel {
      margin-bottom: 20px;
      background-color: #fff;
      border: 1px solid #ddd;
      border-radius: 4px;
      box-shadow: 0 1px 1px rgba(0,0,0,.05);
    }
    .panel-primary {
      border-color: #337ab7;
    }
    .panel-heading {
      color: #fff;
      background-color: #337ab7;
      border-color: #337ab7;
      padding: 10px 15px;
      border-bottom: 1px solid transparent;
      border-top-left-radius: 3px;
      border-top-right-radius: 3px;
    }
    .list-group {
      padding-left: 0;
      margin-bottom: 0;
    }
    .list-group-item {
      position: relative;
      display: block;
      padding: 10px 15px;
      margin-bottom: -1px;
      background-color: #fff;
      border: 1px solid #ddd;
    }
    .list-group-item:first-child {
      border-top-left-radius: 0;
      border-top-right-radius: 0;
    }
    .list-group-item:last-child {
      margin-bottom: 0;
      border-bottom-right-radius: 3px;
      border-bottom-left-radius: 3px;
    }
    .list-group-item a {
      color: #337ab7;
      text-decoration: none;
    }
    /* // index.jsp 스타일 끝 */


    /* Header 스타일 (Bootstrap navbar 흉내) */
    .app-header {
      background-color: #f8f9fa;
      border-bottom: 1px solid #e7e7e7;
      padding: 0.5rem 1rem;
      position: fixed;
      top: 0;
      left: 0;
      right: 0;
      z-index: 1030;
      min-height: 50px;
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .app-header a {
      color: #007bff;
      text-decoration: none;
      padding: 0.5rem;
    }
    .app-header .brand {
      font-size: 1.25rem;
      font-weight: bold;
      color: #333;
    }
    .app-header nav a, .app-header nav button {
      margin-left: 10px;
      padding: 0.5rem 0.75rem;
      border: none;
      background: none;
      cursor: pointer;
      font-size: 1rem;
    }
    .app-header nav button {
      color: #007bff;
    }

    /* Footer 스타일 */
    .app-footer {
      text-align: center;
      padding: 1rem;
      margin-top: 2rem;
      background-color: #f8f9fa;
      border-top: 1px solid #e7e7e7;
      color: #6c757d;
    }
  `;

  return (
    // 1. AuthProvider로 앱 전체를 감싸 로그인 상태 공유
    <AuthProvider>
      <style>{styles}</style>
      {/* 2. BrowserRouter로 라우팅 활성화 */}
      <BrowserRouter>
        <Header />
        
        <main className="container">
          {/* 3. Routes로 페이지 경로 정의 */}
          <Routes>
            {/* 로그인 여부와 관계없이 접근 가능한 페이지
              index.jsp (로그인 전) -> IndexPage
              loginView.jsp -> LoginPage
            */}
            <Route path="/" element={<IndexPage />} />
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} /> {/* [수정] 회원가입 라우트 추가 */}

            {/* 로그인이 필요한 페이지 (index.jsp에서 로그인 시 main.jsp로 forward)
              ProtectedRoute가 LogonCheckInterceptor 역할을 함
            */}
            <Route
              path="/main"
              element={
                <ProtectedRoute>
                  <MainPage />
                </ProtectedRoute>
              }
            />
            {/* TODO: 내 정보 페이지 라우트
            <Route
              path="/user/my-info"
              element={
                <ProtectedRoute>
                  <MyInfoPage />
                </ProtectedRoute>
              }
            />
            */}

          </Routes>
        </main>
        
        <Footer />
      </BrowserRouter>
    </AuthProvider>
  );
}