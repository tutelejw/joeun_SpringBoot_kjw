// File: src/context/AuthContext.js
import React, { createContext, useState } from 'react';
// [수정] 'is not a function' 오류 해결을 위해 default로 import
// [수정] 캔버스 번들러 오류 해결을 위해 .js 확장자 명시
import api from '../services/api.js';

// 1. AuthContext 생성
export const AuthContext = createContext(null);

// 2. AuthProvider 컴포넌트 생성
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(false);

  // 로그인 함수
  const login = async (userId, password) => {
    setLoading(true);
    try {
      // [수정] api.loginRequest로 호출
      const userData = await api.loginRequest(userId, password);
      
      // UserRestController.java 로직에 따라
      if (userData && userData.password === password) {
        setUser(userData);
      } else {
        setUser(null);
        throw new Error("아이디 또는 비밀번호가 일치하지 않습니다.");
      }
    } catch (error) {
      setUser(null);
      console.error("Login failed:", error);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  // 로그아웃 함수
  const logout = async () => {
    setLoading(true);
    try {
      // [수정] api.logoutRequest로 호출
      await api.logoutRequest();
    } catch (error) {
      console.error("Logout request failed:", error);
    } finally {
      setUser(null);
      setLoading(false);
    }
  };

  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};