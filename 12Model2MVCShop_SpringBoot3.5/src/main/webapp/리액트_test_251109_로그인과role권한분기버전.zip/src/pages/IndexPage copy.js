// File: src/pages/IndexPage.js
import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth.js';

// index.jsp (로그인 전)를 대체하는 페이지
const IndexPage = () => {
  const buttonStyle = {
    display: 'inline-block',
    padding: '0.6rem 1.2rem',
    border: 'none',
    background: '#007bff',
    color: 'white',
    borderRadius: '5px',
    cursor: 'pointer',
    fontWeight: 'bold',
    textDecoration: 'none',
    margin: '0 5px',
  };

  return (
    <div className="jumbotron">
      <h1>Model2 MVC Shop</h1>
      <p>로그인 후 사용가능...</p>
      <p>로그인 전 검색만 가능합니다.</p>
      <p>회원가입 하세요.</p>
      
      <div style={{ textAlign: 'center', marginTop: '20px' }}>
        {/* <Link to="/register" style={buttonStyle}>회원가입</Link> */}
        <Link to="/login" style={buttonStyle}>로 그 인</Link>
      </div>
    </div>
  );
};

export default IndexPage;