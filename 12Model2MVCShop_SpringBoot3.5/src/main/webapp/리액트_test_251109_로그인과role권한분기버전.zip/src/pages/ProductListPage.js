// File: src/pages/ProductListPage.js
// 경로: /product/listProduct/:menu
import React from 'react';
import { useParams, Navigate } from 'react-router-dom';
// [수정] .js 확장자 명시
import { useAuth } from '../hooks/useAuth.js';

const ProductListPage = () => {
  const { menu } = useParams(); // 'search' 또는 'manage'
  const { user } = useAuth();

  // 'manage' 메뉴는 admin만 접근 가능
  if (menu === 'manage' && user.role !== 'admin') {
    return <Navigate to="/main" replace />;
  }
  
  const title = menu === 'manage' ? '판매상품관리' : '상품검색';
  
  return (
    <div className="jumbotron">
      <h1>{title}</h1>
      <p>현재 메뉴: {menu}</p>
      <p>이곳에 상품 목록이 표시됩니다.</p>
    </div>
  );
};

export default ProductListPage;