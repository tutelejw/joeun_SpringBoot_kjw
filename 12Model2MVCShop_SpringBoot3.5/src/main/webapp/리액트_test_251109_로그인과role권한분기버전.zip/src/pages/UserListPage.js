// File: src/pages/UserListPage.js
// 경로: /user/listUser (Admin 전용)
import React from 'react';
// [수정] .js 확장자 명시
import { useAuth } from '../hooks/useAuth.js';
import { Navigate } from 'react-router-dom';

const UserListPage = () => {
  const { user } = useAuth();

  // Admin이 아니면 /main으로 리다이렉트
  if (user.role !== 'admin') {
    return <Navigate to="/main" replace />;
  }

  return (
    <div className="jumbotron">
      <h1>회원정보조회</h1>
      <p>이곳에 전체 회원 목록(관리자용)이 표시됩니다.</p>
    </div>
  );
};

export default UserListPage;