// File: src/pages/MyInfoPage.js
// 경로: /user/getUser/:userId
import React from 'react';
import { useParams } from 'react-router-dom';
// [수정] .js 확장자 명시
import { useAuth } from '../hooks/useAuth.js';

const MyInfoPage = () => {
  const { userId } = useParams();
  const { user } = useAuth(); // 현재 로그인한 사용자 정보

  // 본인 정보인지 확인 (간단한 예시)
  const isMe = user.userId === userId;

  return (
    <div className="jumbotron">
      <h1>개인정보조회</h1>
      <p>조회 대상 ID: {userId}</p>
      {isMe ? (
        <p>이곳에 {user.userName}님의 상세 정보가 표시됩니다.</p>
      ) : (
        <p>다른 사용자의 정보입니다. (관리자 권한 필요)</p>
      )}
    </div>
  );
};

export default MyInfoPage;