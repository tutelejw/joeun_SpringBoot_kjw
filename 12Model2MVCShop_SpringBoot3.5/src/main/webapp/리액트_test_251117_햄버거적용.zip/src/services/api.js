// File: src/services/api.js
import axios from 'axios';

// 동적 API Base URL 설정
// 환경 변수가 있으면 사용하고, 없으면 현재 호스트의 8080 포트 사용
const getApiBaseUrl = () => {
  // .env 파일에 REACT_APP_API_URL이 설정되어 있으면 우선 사용
  if (process.env.REACT_APP_API_URL) {
    return process.env.REACT_APP_API_URL;
  }
  
  // 그렇지 않으면 현재 접속한 호스트의 8080 포트 사용
  // localhost:3000으로 접속 → http://localhost:8080
  // 192.168.0.52:3000으로 접속 → http://192.168.0.52:8080
  return `http://${window.location.hostname}:8080`;
};

// Axios 인스턴스 생성
const api = axios.create({
  baseURL: getApiBaseUrl(), // 동적으로 설정된 Spring Boot 서버 주소
  withCredentials: true, // Spring Session(JSESSIONID) 쿠키를 주고받기 위해 필수
});

// 디버깅용: 현재 사용 중인 API URL 콘솔에 출력
console.log('API Base URL:', getApiBaseUrl());

// UserRestController.java의 /user/json/login (POST)
export const loginRequest = async (userId, password) => {
  const response = await api.post('/user/json/login', {
    userId: userId,
    password: password,
  });
  return response.data; // 컨트롤러가 반환하는 User 객체
};

// 로그아웃 요청 (Spring Security 등을 사용할 경우 세션 무효화)
// 여기서는 세션 관리를 브라우저 쿠키에 의존하므로,
// 클라이언트 측에서는 상태만 null로 변경합니다. (AuthContext 참조)
// 만약 서버에 /user/logout 엔드포인트가 있다면 호출합니다.
export const logoutRequest = async () => {
  // Spring Boot에 /user/logout 엔드포인트가 있다고 가정 (GET 요청)
  try {
    await api.get('/user/logout');
  } catch (error) {
    console.warn("Logout request to server failed, but logging out client-side.");
  }
};

// [수정] 'is not a function' 오류 해결을 위해
// 함수들을 객체로 묶어 default로 export합니다.
export default {
  loginRequest,
  logoutRequest
};