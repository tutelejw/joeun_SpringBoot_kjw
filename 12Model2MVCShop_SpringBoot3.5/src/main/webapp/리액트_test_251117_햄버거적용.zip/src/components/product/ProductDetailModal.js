// File: src/components/product/ProductDetailModal.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';

const ProductDetailModal = ({ prodNo, onClose }) => {
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  useEffect(() => {
    if (prodNo) {
      fetchProductDetail();
    }
  }, [prodNo]);

  const fetchProductDetail = async () => {
    setLoading(true);
    setError('');
    
    try {
      const response = await axios.post('/product/json/getProduct', {
        prodNo: prodNo
      }, {
        withCredentials: true
      });
      
      console.log('상품 상세 조회:', response.data);
      setProduct(response.data);
      
    } catch (err) {
      console.error('상품 상세 조회 실패:', err);
      setError('상품 정보를 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  // ESC 키로 닫기
  useEffect(() => {
    const handleEscape = (e) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };
    
    document.addEventListener('keydown', handleEscape);
    return () => document.removeEventListener('keydown', handleEscape);
  }, [onClose]);

  // 배경 클릭 시 닫기
  const handleBackdropClick = (e) => {
    if (e.target === e.currentTarget) {
      onClose();
    }
  };

  return (
    <>
      <style>{`
        .modal-backdrop {
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          bottom: 0;
          background-color: rgba(0, 0, 0, 0.5);
          display: flex;
          justify-content: center;
          align-items: center;
          z-index: 9999;
          animation: fadeIn 0.2s ease-in;
        }
        
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
        
        .modal-content {
          background: white;
          border-radius: 8px;
          width: 90%;
          max-width: 600px;
          max-height: 90vh;
          overflow-y: auto;
          box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
          animation: slideUp 0.3s ease-out;
        }
        
        @keyframes slideUp {
          from {
            transform: translateY(50px);
            opacity: 0;
          }
          to {
            transform: translateY(0);
            opacity: 1;
          }
        }
        
        .modal-header {
          padding: 20px;
          border-bottom: 1px solid #e7e7e7;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .modal-header h2 {
          margin: 0;
          font-size: 1.5rem;
          color: #333;
        }
        
        .modal-close {
          background: none;
          border: none;
          font-size: 2rem;
          cursor: pointer;
          color: #666;
          padding: 0;
          width: 40px;
          height: 40px;
          display: flex;
          align-items: center;
          justify-content: center;
          border-radius: 4px;
        }
        
        .modal-close:hover {
          background-color: #f0f0f0;
          color: #333;
        }
        
        .modal-body {
          padding: 20px;
        }
        
        .product-image {
          width: 100%;
          max-height: 300px;
          object-fit: cover;
          border-radius: 8px;
          margin-bottom: 20px;
        }
        
        .product-info-table {
          width: 100%;
          border-collapse: collapse;
        }
        
        .product-info-table tr {
          border-bottom: 1px solid #f0f0f0;
        }
        
        .product-info-table th {
          text-align: left;
          padding: 12px;
          background-color: #f8f9fa;
          font-weight: bold;
          width: 30%;
          color: #333;
        }
        
        .product-info-table td {
          padding: 12px;
          color: #666;
        }
        
        .modal-footer {
          padding: 20px;
          border-top: 1px solid #e7e7e7;
          text-align: right;
        }
        
        .btn-close {
          padding: 10px 20px;
          background-color: #6c757d;
          color: white;
          border: none;
          border-radius: 4px;
          cursor: pointer;
          font-size: 1rem;
        }
        
        .btn-close:hover {
          background-color: #5a6268;
        }
        
        .loading-spinner {
          text-align: center;
          padding: 40px;
          color: #666;
        }
        
        .error-message {
          text-align: center;
          padding: 40px;
          color: #dc3545;
        }
        
        @media (max-width: 768px) {
          .modal-content {
            width: 95%;
            max-height: 95vh;
          }
          
          .modal-header h2 {
            font-size: 1.25rem;
          }
          
          .product-info-table th,
          .product-info-table td {
            padding: 8px;
            font-size: 0.9rem;
          }
        }
      `}</style>
      
      <div className="modal-backdrop" onClick={handleBackdropClick}>
        <div className="modal-content">
          <div className="modal-header">
            <h2>상품 상세정보</h2>
            <button className="modal-close" onClick={onClose} aria-label="닫기">
              ×
            </button>
          </div>
          
          <div className="modal-body">
            {loading ? (
              <div className="loading-spinner">로딩 중...</div>
            ) : error ? (
              <div className="error-message">{error}</div>
            ) : product ? (
              <>
                {product.fileName && (
                  <img 
                    src={`/images/uploadFiles/${product.fileName}`} 
                    alt={product.prodName}
                    className="product-image"
                    onError={(e) => {
                      e.target.src = 'https://via.placeholder.com/600x300?text=No+Image';
                    }}
                  />
                )}
                
                <table className="product-info-table">
                  <tbody>
                    <tr>
                      <th>상품번호</th>
                      <td>{product.prodNo}</td>
                    </tr>
                    <tr>
                      <th>상품명</th>
                      <td><strong>{product.prodName}</strong></td>
                    </tr>
                    <tr>
                      <th>상품상세정보</th>
                      <td style={{whiteSpace: 'pre-wrap'}}>{product.prodDetail || '-'}</td>
                    </tr>
                    <tr>
                      <th>제조일자</th>
                      <td>{product.manuDate || '-'}</td>
                    </tr>
                    <tr>
                      <th>가격</th>
                      <td>
                        <strong style={{fontSize: '1.2rem', color: '#337ab7'}}>
                          {product.price ? product.price.toLocaleString() : '0'}원
                        </strong>
                      </td>
                    </tr>
                    <tr>
                      <th>재고수량</th>
                      <td>{product.stock || 0}개</td>
                    </tr>
                    <tr>
                      <th>등록일</th>
                      <td>{product.regDate || '-'}</td>
                    </tr>
                  </tbody>
                </table>
              </>
            ) : (
              <div className="error-message">상품 정보가 없습니다.</div>
            )}
          </div>
          
          <div className="modal-footer">
            <button className="btn-close" onClick={onClose}>
              닫기
            </button>
          </div>
        </div>
      </div>
    </>
  );
};

export default ProductDetailModal;