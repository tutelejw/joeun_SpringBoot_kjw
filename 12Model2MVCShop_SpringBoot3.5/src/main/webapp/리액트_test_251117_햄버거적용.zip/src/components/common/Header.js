// File: src/components/common/Header.js
import React, { useState, useEffect, useRef } from 'react';
import { Link, useNavigate } from 'react-router-dom';
// [수정] .js 확장자 제거
import { useAuth } from '../../hooks/useAuth';

// Dropdown 컴포넌트
const Dropdown = ({ title, children }) => {
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (ref.current && !ref.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [ref]);

  return (
    <div className="dropdown" ref={ref}>
      <button 
        className="dropdown-toggle" 
        onClick={() => setIsOpen(!isOpen)}
      >
        {title} <span className="caret">▼</span>
      </button>
      
      {isOpen && (
        <div className="dropdown-menu">
          {React.Children.toArray(children)
            .filter(Boolean)
            .map((child) =>
              React.cloneElement(child, { 
                onClick: () => {
                  setIsOpen(false);
                  if(child.props.onClick) child.props.onClick();
                }
              })
          )}
        </div>
      )}
    </div>
  );
};

// toolbar.jsp를 대체하는 Header 컴포넌트
const Header = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/');
    setMobileMenuOpen(false);
  };

  const closeMobileMenu = () => {
    setMobileMenuOpen(false);
  };

  return (
    <>
      <style>{`
        /* 헤더 기본 스타일 */
        .app-header {
          background-color: #f8f9fa;
          border-bottom: 1px solid #e7e7e7;
          padding: 0.5rem 1rem;
          position: fixed;
          top: 0;
          left: 0;
          right: 0;
          z-index: 1030;
          min-height: 50px;
          display: flex;
          justify-content: space-between;
          align-items: center;
        }
        
        .app-header .brand {
          font-size: 1.25rem;
          font-weight: bold;
          color: #333;
          text-decoration: none;
        }
        
        /* 햄버거 버튼 */
        .hamburger {
          display: none;
          flex-direction: column;
          background: none;
          border: none;
          cursor: pointer;
          padding: 0.5rem;
        }
        
        .hamburger span {
          width: 25px;
          height: 3px;
          background-color: #333;
          margin: 3px 0;
          transition: 0.3s;
          border-radius: 2px;
        }
        
        /* 햄버거 활성화 시 애니메이션 */
        .hamburger.active span:nth-child(1) {
          transform: rotate(-45deg) translate(-5px, 6px);
        }
        
        .hamburger.active span:nth-child(2) {
          opacity: 0;
        }
        
        .hamburger.active span:nth-child(3) {
          transform: rotate(45deg) translate(-5px, -6px);
        }
        
        /* 데스크톱 네비게이션 */
        .app-header nav {
          display: flex;
          align-items: center;
        }
        
        .app-header nav a, 
        .app-header nav button.logout-btn,
        .app-header nav span {
          margin-left: 10px;
          padding: 0.5rem 0.75rem;
          border: none;
          background: none;
          cursor: pointer;
          font-size: 1rem;
          color: #333;
          text-decoration: none;
        }
        
        .app-header nav button.logout-btn {
          color: #007bff;
        }
        
        .app-header nav button.logout-btn:hover {
          text-decoration: underline;
        }
        
        /* 드롭다운 스타일 */
        .dropdown {
          position: relative;
          display: inline-block;
          margin-left: 10px;
        }
        
        .dropdown-toggle {
          background: none;
          border: none;
          padding: 0.5rem 0.75rem;
          font-size: 1rem;
          color: #333;
          cursor: pointer;
        }
        
        .dropdown-toggle:hover {
          background-color: #f0f0f0;
        }
        
        .dropdown-menu {
          position: absolute;
          top: 100%;
          left: 0;
          z-index: 1000;
          display: block;
          min-width: 160px;
          padding: 5px 0;
          margin: 2px 0 0;
          font-size: 1rem;
          text-align: left;
          list-style: none;
          background-color: #fff;
          background-clip: padding-box;
          border: 1px solid rgba(0,0,0,.15);
          border-radius: 4px;
          box-shadow: 0 6px 12px rgba(0,0,0,.175);
        }
        
        .dropdown-menu a {
          display: block;
          padding: 3px 20px;
          clear: both;
          font-weight: 400;
          line-height: 1.42857143;
          color: #333;
          white-space: nowrap;
          text-decoration: none;
        }
        
        .dropdown-menu a:hover {
          color: #262626;
          background-color: #f5f5f5;
        }
        
        /* 모바일 메뉴 */
        .mobile-menu {
          display: none;
          position: fixed;
          top: 50px;
          left: 0;
          right: 0;
          background-color: #fff;
          border-bottom: 1px solid #e7e7e7;
          box-shadow: 0 4px 6px rgba(0,0,0,0.1);
          max-height: 0;
          overflow: hidden;
          transition: max-height 0.3s ease-in-out;
          z-index: 1020;
        }
        
        .mobile-menu.open {
          max-height: 500px;
          padding: 1rem 0;
        }
        
        .mobile-menu-item {
          padding: 0.75rem 1rem;
          border-bottom: 1px solid #f0f0f0;
        }
        
        .mobile-menu-item a,
        .mobile-menu-item button {
          display: block;
          width: 100%;
          text-align: left;
          padding: 0.5rem;
          background: none;
          border: none;
          color: #333;
          font-size: 1rem;
          text-decoration: none;
          cursor: pointer;
        }
        
        .mobile-menu-item a:hover,
        .mobile-menu-item button:hover {
          background-color: #f5f5f5;
        }
        
        .mobile-submenu {
          padding-left: 1rem;
          margin-top: 0.5rem;
        }
        
        .mobile-submenu a {
          padding: 0.5rem;
          display: block;
          color: #666;
          font-size: 0.9rem;
        }
        
        /* 반응형: 768px 이하에서 햄버거 메뉴 표시 */
        @media (max-width: 768px) {
          .hamburger {
            display: flex;
          }
          
          .app-header nav {
            display: none;
          }
          
          .mobile-menu {
            display: block;
          }
        }
      `}</style>
      
      <header className="app-header">
        <Link to={user ? "/main" : "/"} className="brand">
          Model2 MVC Shop
        </Link>
        
        {/* 햄버거 버튼 (모바일) */}
        <button 
          className={`hamburger ${mobileMenuOpen ? 'active' : ''}`}
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          aria-label="메뉴"
        >
          <span></span>
          <span></span>
          <span></span>
        </button>
        
        {/* 데스크톱 네비게이션 */}
        <nav>
          {user ? (
            // 로그인 상태
            <>
              {/* 1. 회원관리 드롭다운 */}
              <Dropdown title="회원관리">
                <Link to={`/user/getUser/${user.userId}`}>개인정보조회</Link>
                {user.role === 'admin' && (
                  <Link to="/user/listUser">회원정보조회</Link>
                )}
              </Dropdown>

              {/* 2. 판매상품관리 드롭다운 (admin only) */}
              {user.role === 'admin' && (
                <Dropdown title="판매상품관리">
                  <Link to="/product/addProduct">판매상품등록</Link>
                  <Link to="/product/listProduct/manage">판매상품관리</Link>
                </Dropdown>
              )}
              
              {/* 3. 상품구매 드롭다운 */}
              <Dropdown title="상품구매">
                <Link to="/product/listProduct/search">상품검색</Link>
                {user.role === 'user' && (
                  <Link to="/purchase/listPurchase">구매이력조회</Link>
                )}
              </Dropdown>

              <span style={{marginLeft: '15px', color: '#333'}}>{user.userName}님</span>
              <button onClick={handleLogout} className="logout-btn">로그아웃</button>
            </>
          ) : (
            // 비로그인 상태
            <>
              <Link to="/register">회원가입</Link>
              <Link to="/login">로그인</Link>
            </>
          )}
        </nav>
      </header>
      
      {/* 모바일 메뉴 */}
      <div className={`mobile-menu ${mobileMenuOpen ? 'open' : ''}`}>
        {user ? (
          // 로그인 상태
          <>
            <div className="mobile-menu-item">
              <div style={{fontWeight: 'bold', marginBottom: '0.5rem'}}>회원관리</div>
              <div className="mobile-submenu">
                <Link to={`/user/getUser/${user.userId}`} onClick={closeMobileMenu}>
                  개인정보조회
                </Link>
                {user.role === 'admin' && (
                  <Link to="/user/listUser" onClick={closeMobileMenu}>
                    회원정보조회
                  </Link>
                )}
              </div>
            </div>

            {user.role === 'admin' && (
              <div className="mobile-menu-item">
                <div style={{fontWeight: 'bold', marginBottom: '0.5rem'}}>판매상품관리</div>
                <div className="mobile-submenu">
                  <Link to="/product/addProduct" onClick={closeMobileMenu}>
                    판매상품등록
                  </Link>
                  <Link to="/product/listProduct/manage" onClick={closeMobileMenu}>
                    판매상품관리
                  </Link>
                </div>
              </div>
            )}
            
            <div className="mobile-menu-item">
              <div style={{fontWeight: 'bold', marginBottom: '0.5rem'}}>상품구매</div>
              <div className="mobile-submenu">
                <Link to="/product/listProduct/search" onClick={closeMobileMenu}>
                  상품검색
                </Link>
                {user.role === 'user' && (
                  <Link to="/purchase/listPurchase" onClick={closeMobileMenu}>
                    구매이력조회
                  </Link>
                )}
              </div>
            </div>

            <div className="mobile-menu-item">
              <span style={{color: '#666'}}>{user.userName}님</span>
              <button onClick={handleLogout}>로그아웃</button>
            </div>
          </>
        ) : (
          // 비로그인 상태
          <>
            <div className="mobile-menu-item">
              <Link to="/register" onClick={closeMobileMenu}>회원가입</Link>
            </div>
            <div className="mobile-menu-item">
              <Link to="/login" onClick={closeMobileMenu}>로그인</Link>
            </div>
          </>
        )}
      </div>
    </>
  );
};

export default Header;