// File: src/components/common/Footer.js
import React from 'react';

const Footer = () => {
  return (
    <footer className="app-footer">
      <div className="container">
        <p>&copy; Model2MVCShop. All Rights Reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;