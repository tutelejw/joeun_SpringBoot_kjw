// File: src/components/common/ProtectedRoute.js
import React from 'react';
import { Navigate, useLocation } from 'react-router-dom';
// [수정] .js 확장자 제거
import { useAuth } from '../../hooks/useAuth';

/**
 * 로그인이 필요한 페이지를 감싸는 컴포넌트
 * LogonCheckInterceptor.java의 역할을 클라이언트에서 수행
 */
const ProtectedRoute = ({ children }) => {
  const { user } = useAuth();
  const location = useLocation();

  if (!user) {
    // 로그인이 안 되어있으면,
    // /login 페이지로 리다K렉트
    // state: { from: location }은 로그인 후 원래 가려던 페이지로 돌려보내기 위함
    return <Navigate to="/login" state={{ from: location }} replace />;
  }

  // 로그인이 되어있으면 자식 컴포넌트(요청한 페이지)를 렌더링
  return children;
};

export default ProtectedRoute;