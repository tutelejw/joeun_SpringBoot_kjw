// src/pages/ProductListPage.js
import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';
import { BsGridFill, BsListUl } from 'react-icons/bs';

const ProductListPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const params = new URLSearchParams(location.search);
  const initialCondition = params.get('searchCondition') || '0';
  const initialKeyword = params.get('searchKeyword') || '';

  const [products, setProducts] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const pageSize = 10;
  const [totalCount, setTotalCount] = useState(0);
  const [searchCondition, setSearchCondition] = useState(initialCondition);
  const [searchKeyword, setSearchKeyword] = useState(initialKeyword);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [viewType, setViewType] = useState('card');

  const loadingRef = useRef(false);
  const hasMoreRef = useRef(true);
  const containerRef = useRef(null);

  const getImageUrl = (product) =>
    product.fileName ? `/images/${product.fileName}` : 'https://via.placeholder.com/180?text=No+Image';

  const fetchProducts = async (page = 1, condition = searchCondition, keyword = searchKeyword, append = false) => {
    if (loadingRef.current) return;
    loadingRef.current = true;
    setLoading(true);
    setError('');
    try {
      const res = await axios.get('/product/json/getProductListScroll', {
        params: {
          currentPage: page,
          pageSize,
          searchCondition: condition,
          searchKeyword: keyword
        }
      });
      const list = res.data.list || [];
      const total = res.data.totalCount || 0;
      setTotalCount(total);

      if (append) {
        setProducts(prev => [...prev, ...list]);
      } else {
        setProducts(list);
      }
      setCurrentPage(page);
      hasMoreRef.current = (page * pageSize) < total;
    } catch (err) {
      setError('상품 목록 조회에 실패했습니다.');
    } finally {
      setLoading(false);
      loadingRef.current = false;
    }
  };

  // 무한스크롤
  useEffect(() => {
    const onScroll = () => {
      if (loadingRef.current || !hasMoreRef.current) return;
      const scrollTop = window.scrollY || window.pageYOffset;
      const windowHeight = window.innerHeight;
      const fullHeight = document.documentElement.scrollHeight;
      if (scrollTop + windowHeight + 100 >= fullHeight) {
        fetchProducts(currentPage + 1, searchCondition, searchKeyword, true);
      }
    };
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, [currentPage, searchCondition, searchKeyword]);

  useEffect(() => {
    fetchProducts(1, searchCondition, searchKeyword, false);
  }, [searchCondition, searchKeyword]);

  useEffect(() => {
    if (!loading && hasMoreRef.current && containerRef.current) {
      const containerHeight = containerRef.current.clientHeight;
      const windowHeight = window.innerHeight;
      if (containerHeight < windowHeight) {
        fetchProducts(currentPage + 1, searchCondition, searchKeyword, true);
      }
    }
  }, [products, loading, currentPage, searchCondition, searchKeyword]);

  const handleSearchChange = (e) => setSearchKeyword(e.target.value);

  const handleSearch = e => {
    e.preventDefault();
    fetchProducts(1, searchCondition, searchKeyword, false);
  };

  const handleProductClick = prodNo => {
    navigate(`/product/getProduct/${prodNo}`);
  };

  return (
    <div className="container" ref={containerRef}>
      <h2 style={{marginBottom: "20px", marginTop: '15px', fontWeight:'bold'}}>상품 목록</h2>
      
      {/* ------- 검색창 + 카드/리스트 토글 오른쪽 정렬 -------- */}
      <form onSubmit={handleSearch} style={{margin: 0, padding: 0}}>
        <div style={{
          display: 'flex',
          flexDirection: 'row',
          justifyContent: 'flex-end',    // <-- 전체 검색+토글 오른쪽 정렬
          alignItems: 'center',
          gap: '10px',
          marginBottom: '22px'
        }}>
          <select
            value={searchCondition}
            onChange={e => setSearchCondition(e.target.value)}
            style={{
              fontSize:'1rem',
              border: '2px solid #675afe',
              borderRadius: '10px',
              padding: '8px 10px',
              marginRight: '4px',
              background: '#f7f7fc'
            }}
          >
            <option value="0">상품NO</option>
            <option value="1">상품명</option>
          </select>
          <input
            type="text"
            value={searchKeyword}
            onChange={handleSearchChange}
            placeholder="상품 이름으로 검색..."
            style={{
              minWidth: '220px',
              maxWidth: '350px',
              fontSize: '1rem',
              border: '2px solid #675afe',
              borderRadius: '10px',
              padding: '10px 16px',
              outline: 'none',
              boxShadow: '0 0 0 1.5px rgba(110,90,250,0.07)',
              marginRight: '4px'
            }}
          />
          <div style={{
            display: 'flex',
            alignItems: 'center',
            background: '#f5f5f8',
            borderRadius: '12px',
            boxShadow: '0 1px 8px #eee',
            padding: '3px 4px',
            gap: '1px'
          }}>
            <button
              type="button"
              onClick={() => setViewType('card')}
              style={{
                background: viewType === 'card' ? '#e5e8ff' : 'transparent',
                border: 'none',
                borderRadius: '8px',
                padding: '7px 13px',
                marginRight: '2px',
                boxShadow: viewType === 'card' ? '0 2px 10px #aabdfc' : 'none',
                transition: 'background 0.16s',
                cursor: 'pointer'
              }}
              aria-label="카드형 보기"
            >
              <BsGridFill color={viewType === 'card' ? "#534bf2" : "#888"} size={23} />
            </button>
            <button
              type="button"
              onClick={() => setViewType('list')}
              style={{
                background: viewType === 'list' ? '#e5e8ff' : 'transparent',
                border: 'none',
                borderRadius: '8px',
                padding: '7px 13px',
                marginLeft: '2px',
                boxShadow: viewType === 'list' ? '0 2px 10px #aabdfc' : 'none',
                transition: 'background 0.16s',
                cursor: 'pointer'
              }}
              aria-label="리스트형 보기"
            >
              <BsListUl color={viewType === 'list' ? "#534bf2" : "#888"} size={23} />
            </button>
          </div>
        </div>
      </form>
      {/* --------------------------------------------------- */}

      {viewType === 'card' && (
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(230px, 1fr))',
          gap: '22px',
        }}>
          {products.map(prod => (
            <div key={prod.prodNo}
                 style={{
                   background: '#fff',
                   boxShadow: '0 2.5px 10px #eee',
                   borderRadius: '13px',
                   overflow: 'hidden',
                   cursor: 'pointer',
                   transition: 'transform .13s',
                 }}
                 onClick={() => handleProductClick(prod.prodNo)}
            >
              <img
                src={getImageUrl(prod)}
                alt={prod.prodName}
                style={{ width: '100%', height: '160px', objectFit: 'cover', background: '#fafafa' }}
                loading="lazy"
              />
              <div style={{ padding: '16px 16px 12px 16px' }}>
                <div style={{ fontWeight: 700, marginBottom: '6px', fontSize:'1.08rem', overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap' }}>
                  {prod.prodName}
                </div>
                <div style={{ color: '#555', fontSize: '0.97rem', marginBottom:'11px', minHeight:'32px',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>
                  {prod.prodDetail}
                </div>
                <div style={{ fontWeight: 700, color: '#534bf2', fontSize:'1.09rem' }}>
                  {prod.price.toLocaleString()}원
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {viewType === 'list' && (
        <div>
          {products.map(prod => (
            <div key={prod.prodNo}
                 style={{
                   display:"flex", alignItems:"center",
                   background: '#fff',
                   marginBottom: '15px',
                   boxShadow: '0 2px 8px #eee',
                   borderRadius: '13px',
                   cursor: 'pointer',
                   padding: '18px'
                 }}
                 onClick={() => handleProductClick(prod.prodNo)}
            >
              <img
                src={getImageUrl(prod)}
                alt={prod.prodName}
                style={{ width: '80px', height: '80px', objectFit: 'cover', borderRadius: '8px', background:'#fafafa', marginRight:'26px' }}
                loading="lazy"
              />
              <div style={{ flex: 1 }}>
                <div style={{ fontWeight: 700, fontSize: '1.07rem', marginBottom: '3px', overflow: 'hidden', whiteSpace:'nowrap', textOverflow:'ellipsis' }}>
                  {prod.prodName}
                </div>
                <div style={{ color: '#555', fontSize:'0.97rem', minHeight:'18px', marginBottom:'2px', overflow:'hidden', textOverflow:'ellipsis',whiteSpace:'nowrap' }}>
                  {prod.prodDetail}
                </div>
              </div>
              <div style={{ fontWeight: 700, color: '#534bf2', fontSize:'1.11rem', whiteSpace:'nowrap', marginLeft:'18px' }}>
                {prod.price.toLocaleString()}원
              </div>
            </div>
          ))}
        </div>
      )}

      {loading && <p style={{ textAlign: 'center' }}>로딩 중...</p>}
      {!loading && products.length === 0 && <p>검색 결과가 없습니다.</p>}
      {!loading && !hasMoreRef.current && products.length > 0 && (
        <p style={{ textAlign: 'center' }}>모든 상품을 불러왔습니다.</p>
      )}
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default ProductListPage;
