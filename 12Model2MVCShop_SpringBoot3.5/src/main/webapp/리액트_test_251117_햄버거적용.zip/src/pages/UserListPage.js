// File: src/pages/UserListPage.js
// 경로: /user/listUser (Admin 전용)
import React, { useState, useEffect } from 'react';
import axios from 'axios';
// [수정] .js 확장자 명시
import { useAuth } from '../hooks/useAuth.js';
import { Navigate, useNavigate } from 'react-router-dom';

const UserListPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [userList, setUserList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // 검색 조건
  const [searchCondition, setSearchCondition] = useState('0'); // 0: ID, 1: 이름
  const [searchKeyword, setSearchKeyword] = useState('');
  const [currentPage, setCurrentPage] = useState(1);

  // 회원 목록 조회
  const fetchUserList = async () => {
    setLoading(true);
    setError('');
    
    try {
      console.log('=== 회원 목록 조회 시작 ===');
      console.log('요청 파라미터:', {
        currentPage: currentPage,
        pageSize: 10,
        searchCondition: searchCondition,
        searchKeyword: searchKeyword
      });
      
      const response = await axios.post('/user/json/getUserList', {
        currentPage: currentPage,
        pageSize: 10,
        searchCondition: searchCondition,
        searchKeyword: searchKeyword
      }, {
        withCredentials: true
      });
      
      console.log('=== API 응답 전체 ===');
      console.log('response:', response);
      console.log('response.data:', response.data);
      console.log('response.data 타입:', typeof response.data);
      console.log('response.data는 배열?:', Array.isArray(response.data));
      
      // 응답 데이터의 모든 키 출력
      if (typeof response.data === 'object' && response.data !== null) {
        console.log('response.data의 키들:', Object.keys(response.data));
      }
      
      // response.data가 배열인 경우와 객체인 경우를 모두 처리
      let users = [];
      if (Array.isArray(response.data)) {
        users = response.data;
        console.log('배열 형태의 데이터, 사용자 수:', users.length);
      } else if (response.data.list) {
        users = response.data.list;
        console.log('객체.list 형태의 데이터, 사용자 수:', users.length);
      } else if (response.data.users) {
        users = response.data.users;
        console.log('객체.users 형태의 데이터, 사용자 수:', users.length);
      } else {
        console.warn('예상하지 못한 데이터 형태입니다. 전체 response.data를 확인하세요.');
        console.log('response.data 전체:', JSON.stringify(response.data, null, 2));
        users = [];
      }
      
      console.log('최종 설정될 userList:', users);
      setUserList(users);
      
    } catch (err) {
      console.error('=== 회원 목록 조회 실패 ===');
      console.error('에러 객체:', err);
      console.error('에러 응답:', err.response);
      console.error('에러 데이터:', err.response?.data);
      setError('회원 목록을 불러오는데 실패했습니다. ' + (err.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user && user.role === 'admin') {
      fetchUserList();
    }
  }, [currentPage]);

  // Admin이 아니면 /main으로 리다이렉트
  if (user.role !== 'admin') {
    return <Navigate to="/main" replace />;
  }

  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1);
    fetchUserList();
  };

  const handleUserClick = (userId) => {
    navigate(`/user/getUser/${userId}`);
  };

  // 스타일
  const tableStyle = {
    width: '100%',
    borderCollapse: 'collapse',
    marginTop: '20px',
    backgroundColor: 'white',
  };

  const thStyle = {
    backgroundColor: '#337ab7',
    color: 'white',
    padding: '12px',
    textAlign: 'center',
    borderBottom: '2px solid #ddd',
  };

  const tdStyle = {
    padding: '10px',
    textAlign: 'center',
    borderBottom: '1px solid #ddd',
  };

  const searchFormStyle = {
    marginBottom: '20px',
    padding: '15px',
    backgroundColor: '#f9f9f9',
    borderRadius: '4px',
    border: '1px solid #ddd',
  };

  const inputStyle = {
    padding: '8px',
    marginRight: '10px',
    border: '1px solid #ccc',
    borderRadius: '4px',
  };

  const buttonStyle = {
    padding: '8px 16px',
    backgroundColor: '#337ab7',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  };

  return (
    <div>
      <h1>회원정보조회</h1>
      
      {/* 검색 폼 */}
      <form onSubmit={handleSearch} style={searchFormStyle}>
        <select 
          value={searchCondition} 
          onChange={(e) => setSearchCondition(e.target.value)}
          style={inputStyle}
        >
          <option value="0">ID</option>
          <option value="1">이름</option>
        </select>
        
        <input
          type="text"
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
          placeholder="검색어를 입력하세요"
          style={inputStyle}
        />
        
        <button type="submit" style={buttonStyle}>검색</button>
      </form>

      {/* 로딩 상태 */}
      {loading && <p>로딩 중...</p>}
      
      {/* 에러 메시지 */}
      {error && <p style={{color: 'red'}}>{error}</p>}
      
      {/* 회원 목록 테이블 */}
      {!loading && !error && (
        <table style={tableStyle}>
          <thead>
            <tr>
              <th style={thStyle}>No</th>
              <th style={thStyle}>아이디</th>
              <th style={thStyle}>이름</th>
              <th style={thStyle}>이메일</th>
              <th style={thStyle}>전화번호</th>
              <th style={thStyle}>가입일</th>
              <th style={thStyle}>권한</th>
            </tr>
          </thead>
          <tbody>
            {userList.length > 0 ? (
              userList.map((u, index) => (
                <tr 
                  key={u.userId} 
                  style={{cursor: 'pointer'}}
                  onClick={() => handleUserClick(u.userId)}
                  onMouseEnter={(e) => e.currentTarget.style.backgroundColor = '#f5f5f5'}
                  onMouseLeave={(e) => e.currentTarget.style.backgroundColor = 'white'}
                >
                  <td style={tdStyle}>{(currentPage - 1) * 10 + index + 1}</td>
                  <td style={tdStyle}>{u.userId}</td>
                  <td style={tdStyle}>{u.userName}</td>
                  <td style={tdStyle}>{u.email}</td>
                  <td style={tdStyle}>{u.phone}</td>
                  <td style={tdStyle}>{u.regDate ? u.regDate.split(' ')[0] : '-'}</td>
                  <td style={tdStyle}>{u.role === 'admin' ? '관리자' : '일반회원'}</td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="7" style={tdStyle}>조회된 회원이 없습니다.</td>
              </tr>
            )}
          </tbody>
        </table>
      )}
      
      {/* 페이징 */}
      {!loading && userList.length > 0 && (
        <div style={{textAlign: 'center', marginTop: '20px'}}>
          <button 
            onClick={() => setCurrentPage(prev => Math.max(1, prev - 1))}
            disabled={currentPage === 1}
            style={{...buttonStyle, marginRight: '10px'}}
          >
            이전
          </button>
          <span style={{margin: '0 15px'}}>페이지 {currentPage}</span>
          <button 
            onClick={() => setCurrentPage(prev => prev + 1)}
            disabled={userList.length < 10}
            style={buttonStyle}
          >
            다음
          </button>
        </div>
      )}
    </div>
  );
};

export default UserListPage;