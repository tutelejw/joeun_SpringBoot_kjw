// File: src/pages/AddProductPage.js
// 경로: /product/addProduct (Admin 전용)
import React, { useState } from 'react';
import { useNavigate, Navigate } from 'react-router-dom';
import axios from 'axios';
// [수정] .js 확장자 명시
import { useAuth } from '../hooks/useAuth.js';

const AddProductPage = () => {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [formData, setFormData] = useState({
    prodName: '',
    prodDetail: '',
    manuDate: '',
    price: '',
    fileName: '',
    stock: ''
  });
  
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  // Admin이 아니면 /main으로 리다이렉트
  if (user.role !== 'admin') {
    return <Navigate to="/main" replace />;
  }

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    // 유효성 검사
    if (!formData.prodName.trim()) {
      setError('상품명을 입력해주세요.');
      setLoading(false);
      return;
    }
    if (!formData.price || formData.price <= 0) {
      setError('가격을 올바르게 입력해주세요.');
      setLoading(false);
      return;
    }

    try {
      console.log('상품 등록 요청:', formData);
      
      const response = await axios.post('/product/json/addProduct', {
        prodName: formData.prodName,
        prodDetail: formData.prodDetail,
        manuDate: formData.manuDate,
        price: parseInt(formData.price),
        fileName: formData.fileName,
        stock: formData.stock ? parseInt(formData.stock) : 0
      }, {
        withCredentials: true
      });
      
      console.log('상품 등록 응답:', response.data);
      alert('상품이 등록되었습니다.');
      
      // 등록 후 상품 관리 페이지로 이동
      navigate('/product/listProduct/manage');
      
    } catch (err) {
      console.error('상품 등록 실패:', err);
      setError('상품 등록에 실패했습니다. ' + (err.response?.data?.message || err.message));
    } finally {
      setLoading(false);
    }
  };

  const handleReset = () => {
    setFormData({
      prodName: '',
      prodDetail: '',
      manuDate: '',
      price: '',
      fileName: '',
      stock: ''
    });
    setError('');
  };

  // 스타일
  const containerStyle = {
    maxWidth: '800px',
    margin: '0 auto',
    padding: '20px'
  };

  const formStyle = {
    backgroundColor: 'white',
    padding: '30px',
    borderRadius: '8px',
    border: '1px solid #ddd'
  };

  const formGroupStyle = {
    marginBottom: '20px'
  };

  const labelStyle = {
    display: 'block',
    marginBottom: '8px',
    fontWeight: 'bold',
    color: '#333'
  };

  const inputStyle = {
    width: '100%',
    padding: '10px',
    border: '1px solid #ccc',
    borderRadius: '4px',
    fontSize: '14px',
    boxSizing: 'border-box'
  };

  const textareaStyle = {
    ...inputStyle,
    minHeight: '100px',
    resize: 'vertical'
  };

  const buttonContainerStyle = {
    textAlign: 'center',
    marginTop: '30px'
  };

  const buttonStyle = {
    padding: '12px 30px',
    marginRight: '10px',
    backgroundColor: '#337ab7',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
    fontSize: '16px',
    fontWeight: 'bold'
  };

  const resetButtonStyle = {
    ...buttonStyle,
    backgroundColor: '#6c757d'
  };

  const cancelButtonStyle = {
    ...buttonStyle,
    backgroundColor: '#dc3545'
  };

  return (
    <div style={containerStyle}>
      <h1>판매상품등록</h1>
      
      <form onSubmit={handleSubmit} style={formStyle}>
        {/* 상품명 */}
        <div style={formGroupStyle}>
          <label style={labelStyle}>
            상품명 <span style={{color: 'red'}}>*</span>
          </label>
          <input
            type="text"
            name="prodName"
            value={formData.prodName}
            onChange={handleInputChange}
            placeholder="상품명을 입력하세요"
            style={inputStyle}
            required
          />
        </div>

        {/* 상품상세정보 */}
        <div style={formGroupStyle}>
          <label style={labelStyle}>상품상세정보</label>
          <textarea
            name="prodDetail"
            value={formData.prodDetail}
            onChange={handleInputChange}
            placeholder="상품에 대한 상세 설명을 입력하세요"
            style={textareaStyle}
          />
        </div>

        {/* 제조일자 */}
        <div style={formGroupStyle}>
          <label style={labelStyle}>제조일자</label>
          <input
            type="date"
            name="manuDate"
            value={formData.manuDate}
            onChange={handleInputChange}
            style={inputStyle}
          />
        </div>

        {/* 가격 */}
        <div style={formGroupStyle}>
          <label style={labelStyle}>
            가격 <span style={{color: 'red'}}>*</span>
          </label>
          <input
            type="number"
            name="price"
            value={formData.price}
            onChange={handleInputChange}
            placeholder="가격을 입력하세요"
            style={inputStyle}
            min="0"
            required
          />
        </div>

        {/* 상품이미지 */}
        <div style={formGroupStyle}>
          <label style={labelStyle}>상품이미지</label>
          <input
            type="text"
            name="fileName"
            value={formData.fileName}
            onChange={handleInputChange}
            placeholder="이미지 파일명을 입력하세요 (예: product.jpg)"
            style={inputStyle}
          />
          <small style={{color: '#666', fontSize: '12px'}}>
            * 현재는 파일명만 입력 가능합니다. 파일 업로드 기능은 추후 구현 예정입니다.
          </small>
        </div>

        {/* 재고수량 */}
        <div style={formGroupStyle}>
          <label style={labelStyle}>재고수량</label>
          <input
            type="number"
            name="stock"
            value={formData.stock}
            onChange={handleInputChange}
            placeholder="재고수량을 입력하세요"
            style={inputStyle}
            min="0"
          />
        </div>

        {/* 에러 메시지 */}
        {error && (
          <div style={{
            color: 'red',
            backgroundColor: '#ffebee',
            padding: '10px',
            borderRadius: '4px',
            marginBottom: '20px'
          }}>
            {error}
          </div>
        )}

        {/* 버튼 */}
        <div style={buttonContainerStyle}>
          <button 
            type="submit" 
            style={buttonStyle}
            disabled={loading}
          >
            {loading ? '등록 중...' : '등록'}
          </button>
          
          <button 
            type="button" 
            onClick={handleReset}
            style={resetButtonStyle}
            disabled={loading}
          >
            초기화
          </button>
          
          <button 
            type="button" 
            onClick={() => navigate('/product/listProduct/manage')}
            style={cancelButtonStyle}
            disabled={loading}
          >
            취소
          </button>
        </div>
      </form>
    </div>
  );
};

export default AddProductPage;