// File: src/context/AuthContext.js
import React, { createContext, useState } from 'react';
import { loginRequest, logoutRequest } from '../services/api';

// 1. AuthContext 생성
export const AuthContext = createContext(null);

// 2. AuthProvider 컴포넌트 생성
// 이 컴포넌트가 앱 전체를 감싸고, 로그인 상태를 관리합니다.
export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null); // 로그인한 사용자 정보
  const [loading, setLoading] = useState(false); // 로딩 상태

  // 로그인 함수
  const login = async (userId, password) => {
    setLoading(true);
    try {
      const userData = await loginRequest(userId, password);
      
      // API에서 받은 사용자 정보가 유효하고, 비밀번호도 일치하는지 확인
      // (컨트롤러에서 비밀번호가 틀리면 null이나 예외를 반환한다고 가정)
      if (userData && userData.password === password) {
        setUser(userData); // 로그인 성공, user 상태 업데이트
      } else {
        // 컨트롤러에서 비밀번호가 틀려도 user 객체를 반환할 경우 (JSP 로직과 동일하게)
        setUser(null);
        throw new Error("아이디 또는 비밀번호가 일치하지 않습니다.");
      }
    } catch (error) {
      setUser(null);
      console.error("Login failed:", error);
      throw error; // 로그인 페이지에서 에러를 처리할 수 있도록 다시 던짐
    } finally {
      setLoading(false);
    }
  };

  // 로그아웃 함수
  const logout = async () => {
    setLoading(true);
    try {
      await logoutRequest(); // 서버에 로그아웃 요청
    } catch (error) {
      console.error("Logout request failed:", error);
    } finally {
      setUser(null); // 클라이언트 상태를 로그아웃으로 변경
      setLoading(false);
    }
  };

  // 3. Provider로 값(상태, 함수)들을 하위 컴포넌트에 전달
  return (
    <AuthContext.Provider value={{ user, loading, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
};