// src/pages/MyInfoPage.js
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import axios from 'axios';
import { useAuth } from '../hooks/useAuth.js';

const MyInfoPage = () => {
  const { userId } = useParams();
  const { user: currentUser } = useAuth();
  const navigate = useNavigate();

  const [userInfo, setUserInfo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [isEditing, setIsEditing] = useState(false);

  // 수정 모드 입력값 상태
  const [editForm, setEditForm] = useState({
    userName: '',
    email: '',
    phone: '',
    addr: ''
  });

  useEffect(() => {
    fetchUserInfo();
  }, [userId]);

  const fetchUserInfo = async () => {
    setLoading(true);
    setError('');

    try {
      console.log('사용자 정보 조회:', userId);

      // GET 요청, URL 파라미터에 userId 포함
      const response = await axios.get(`/user/json/getUser/${userId}`, { withCredentials: true });

      console.log('사용자 정보 응답:', response.data);

      if (response.data && response.data.userId) {
        setUserInfo(response.data);
        setEditForm({
          userName: response.data.userName || '',
          email: response.data.email || '',
          phone: response.data.phone || '',
          addr: response.data.addr || ''
        });
      } else {
        setError('사용자 정보를 찾을 수 없습니다.');
        setUserInfo(null);
      }
    } catch (err) {
      console.error('사용자 정보 조회 실패:', err);
      setError('사용자 정보를 불러오는데 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  const handleUpdate = async (e) => {
    e.preventDefault();

    try {
      const response = await axios.post('/user/json/updateUser', { userId, ...editForm }, { withCredentials: true });

      console.log('수정 응답:', response.data);
      alert('정보가 수정되었습니다.');
      setIsEditing(false);
      fetchUserInfo();
    } catch (err) {
      console.error('정보 수정 실패:', err);
      alert('정보 수정에 실패했습니다.');
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setEditForm(prev => ({ ...prev, [name]: value }));
  };

  const isMe = currentUser.userId === userId;
  const canEdit = isMe || currentUser.role === 'admin';

  // 스타일 객체
  const containerStyle = { maxWidth: '600px', margin: '0 auto', padding: '20px' };
  const tableStyle = { width: '100%', borderCollapse: 'collapse', marginTop: '20px', backgroundColor: 'white', border: '1px solid #ddd' };
  const thStyle = { backgroundColor: '#f8f9fa', padding: '12px', textAlign: 'left', borderBottom: '1px solid #ddd', width: '30%', fontWeight: 'bold' };
  const tdStyle = { padding: '12px', borderBottom: '1px solid #ddd' };
  const inputStyle = { width: '100%', padding: '8px', border: '1px solid #ccc', borderRadius: '4px', boxSizing: 'border-box' };
  const buttonStyle = { padding: '10px 20px', marginRight: '10px', backgroundColor: '#337ab7', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer' };
  const cancelButtonStyle = { ...buttonStyle, backgroundColor: '#6c757d' };

  if (loading) {
    return (
      <div style={containerStyle}>
        <p>로딩 중...</p>
      </div>
    );
  }

  if (error) {
    return (
      <div style={containerStyle}>
        <p style={{ color: 'red' }}>{error}</p>
      </div>
    );
  }

  if (!userInfo) {
    return (
      <div style={containerStyle}>
        <p>사용자 정보를 찾을 수 없습니다.</p>
      </div>
    );
  }

  return (
    <div style={containerStyle}>
      <h1>개인정보조회</h1>

      {!isMe && (
        <p style={{ color: '#666', marginBottom: '20px' }}>
          {currentUser.role === 'admin' ? '(관리자 권한으로 조회 중)' : '다른 사용자의 정보입니다.'}
        </p>
      )}

      {isEditing ? (
        <form onSubmit={handleUpdate}>
          <table style={tableStyle}>
            <tbody>
              <tr>
                <th style={thStyle}>아이디</th>
                <td style={tdStyle}>{userInfo.userId}</td>
              </tr>
              <tr>
                <th style={thStyle}>이름</th>
                <td style={tdStyle}>
                  <input type="text" name="userName" value={editForm.userName} onChange={handleInputChange} style={inputStyle} required />
                </td>
              </tr>
              <tr>
                <th style={thStyle}>이메일</th>
                <td style={tdStyle}>
                  <input type="email" name="email" value={editForm.email} onChange={handleInputChange} style={inputStyle} />
                </td>
              </tr>
              <tr>
                <th style={thStyle}>전화번호</th>
                <td style={tdStyle}>
                  <input type="tel" name="phone" value={editForm.phone} onChange={handleInputChange} style={inputStyle} />
                </td>
              </tr>
              <tr>
                <th style={thStyle}>주소</th>
                <td style={tdStyle}>
                  <input type="text" name="addr" value={editForm.addr} onChange={handleInputChange} style={inputStyle} />
                </td>
              </tr>
              <tr>
                <th style={thStyle}>권한</th>
                <td style={tdStyle}>{userInfo.role === 'admin' ? '관리자' : '일반회원'}</td>
              </tr>
              <tr>
                <th style={thStyle}>가입일</th>
                <td style={tdStyle}>{userInfo.regDate || '-'}</td>
              </tr>
            </tbody>
          </table>

          <div style={{ marginTop: '20px', textAlign: 'center' }}>
            <button type="submit" style={buttonStyle}>저장</button>
            <button type="button" onClick={() => setIsEditing(false)} style={cancelButtonStyle}>취소</button>
          </div>
        </form>
      ) : (
        <>
          <table style={tableStyle}>
            <tbody>
              <tr>
                <th style={thStyle}>아이디</th>
                <td style={tdStyle}>{userInfo.userId}</td>
              </tr>
              <tr>
                <th style={thStyle}>이름</th>
                <td style={tdStyle}>{userInfo.userName}</td>
              </tr>
              <tr>
                <th style={thStyle}>이메일</th>
                <td style={tdStyle}>{userInfo.email || '-'}</td>
              </tr>
              <tr>
                <th style={thStyle}>전화번호</th>
                <td style={tdStyle}>{userInfo.phone || '-'}</td>
              </tr>
              <tr>
                <th style={thStyle}>주소</th>
                <td style={tdStyle}>{userInfo.addr || '-'}</td>
              </tr>
              <tr>
                <th style={thStyle}>권한</th>
                <td style={tdStyle}>{userInfo.role === 'admin' ? '관리자' : '일반회원'}</td>
              </tr>
              <tr>
                <th style={thStyle}>가입일</th>
                <td style={tdStyle}>{userInfo.regDate || '-'}</td>
              </tr>
            </tbody>
          </table>

          <div style={{ marginTop: '20px', textAlign: 'center' }}>
            {canEdit && (
              <button onClick={() => setIsEditing(true)} style={buttonStyle}>정보수정</button>
            )}
            <button onClick={() => navigate(-1)} style={cancelButtonStyle}>목록으로</button>
          </div>
        </>
      )}
    </div>
  );
};

export default MyInfoPage;
