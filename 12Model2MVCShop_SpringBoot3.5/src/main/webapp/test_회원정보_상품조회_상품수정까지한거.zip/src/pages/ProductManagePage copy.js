// src/pages/ProductManagePage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const ProductManagePage = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const fetchProducts = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get('/product/json/getProductList', {
          params: { currentPage: 1, pageSize: 20 }
        });
        setProducts(res.data.list || []);
      } catch (e) {
        setError('상품 목록 조회 실패');
      } finally {
        setLoading(false);
      }
    };
    fetchProducts();
  }, []);

  const handleUpdateClick = (prodNo) => {
    navigate(`/product/updateProduct/${prodNo}`);
  };

  return (
    <div className="container">
      <h2>상품관리</h2>
      {loading && <p>로딩 중...</p>}
      {error && <p style={{color:'red'}}>{error}</p>}
      <table className="table table-bordered" style={{width:'100%', marginTop:'1rem'}}>
        <thead>
          <tr>
            <th>No</th>
            <th>상품명</th>
            <th>가격</th>
            <th>등록일</th>
            <th>수정</th>
          </tr>
        </thead>
        <tbody>
          {products.map((prod, idx) => (
            <tr key={prod.prodNo}>
              <td>{idx + 1}</td>
              <td>{prod.prodName}</td>
              <td>{prod.price?.toLocaleString()}원</td>
              <td>{prod.regDate}</td>
              <td>
                <button
                  className="btn btn-sm btn-warning"
                  onClick={() => handleUpdateClick(prod.prodNo)}
                >수정</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ProductManagePage;
