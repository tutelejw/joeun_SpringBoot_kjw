// src/pages/ProductListPage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useNavigate, useLocation } from 'react-router-dom';

const ProductListPage = () => {
  const navigate = useNavigate();
  const location = useLocation();

  // 쿼리 파라미터에서 현재 페이지와 검색조건 가져오기 (예: ?currentPage=1&searchCondition=1&searchKeyword=...)
  const params = new URLSearchParams(location.search);
  const initialPage = parseInt(params.get('currentPage')) || 1;
  const initialCondition = params.get('searchCondition') || '0';
  const initialKeyword = params.get('searchKeyword') || '';

  const [products, setProducts] = useState([]);
  const [currentPage, setCurrentPage] = useState(initialPage);
  const [pageSize] = useState(10);
  const [totalCount, setTotalCount] = useState(0);
  const [searchCondition, setSearchCondition] = useState(initialCondition);
  const [searchKeyword, setSearchKeyword] = useState(initialKeyword);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const fetchProducts = async (page = 1, condition = '0', keyword = '') => {
    setLoading(true);
    setError('');
    try {
      const res = await axios.get('/product/json/getProductList', {
        params: {
          currentPage: page,
          pageSize,
          searchCondition: condition,
          searchKeyword: keyword
        }
      });

      // res.data 구조: { list: [...], totalCount: 숫자 }
      setProducts(res.data.list || []);
      setTotalCount(res.data.totalCount || 0);
      setCurrentPage(page);
    } catch (err) {
      console.error(err);
      setError('상품 목록 조회에 실패했습니다.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts(currentPage, searchCondition, searchKeyword);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // 페이지 변경 함수
  const handlePageChange = (page) => {
    fetchProducts(page, searchCondition, searchKeyword);
  };

  // 검색 폼 제출 처리
  const handleSearch = (e) => {
    e.preventDefault();
    fetchProducts(1, searchCondition, searchKeyword);
  };

  // 상품명 클릭 시 상세 페이지 이동
  const handleProductClick = (prodNo) => {
    navigate(`/product/getProduct/${prodNo}`);
  };

  // 페이지네이션 계산
  const totalPages = Math.ceil(totalCount / pageSize);
  const pageNumbers = [];
  for (let i = 1; i <= totalPages; i++) {
    pageNumbers.push(i);
  }

  return (
    <div className="container">
      <h2>상품 목록 조회</h2>

      <form onSubmit={handleSearch} style={{ marginBottom: '1rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
        <select
          value={searchCondition}
          onChange={(e) => setSearchCondition(e.target.value)}
          style={{ padding: '0.25rem' }}
        >
          <option value="0">상품NO</option>
          <option value="1">상품명</option>
        </select>
        <input
          type="text"
          value={searchKeyword}
          onChange={(e) => setSearchKeyword(e.target.value)}
          placeholder="검색어를 입력하세요"
          style={{ flex: '1', padding: '0.3rem' }}
        />
        <button type="submit" style={{ padding: '0.3rem 1rem' }}>검색</button>
      </form>

      {loading && <p>로딩 중...</p>}
      {error && <p style={{ color: 'red' }}>{error}</p>}

      {!loading && products.length === 0 && <p>검색 결과가 없습니다.</p>}

      {!loading && products.length > 0 && (
        <table className="table table-bordered" style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead style={{ backgroundColor: '#f8f9fa' }}>
            <tr>
              <th style={{ width: '5%' }}>No</th>
              <th style={{ width: '60%' }}>상품명</th>
              <th style={{ width: '15%' }}>가격</th>
              <th style={{ width: '20%' }}>등록일</th>
            </tr>
          </thead>
          <tbody>
            {products.map((prod, idx) => (
              <tr key={prod.prodNo} style={{ cursor: 'pointer' }} onClick={() => handleProductClick(prod.prodNo)}>
                <td style={{ textAlign: 'center' }}>{(currentPage - 1) * pageSize + idx + 1}</td>
                <td>{prod.prodName}</td>
                <td>{prod.price.toLocaleString()} 원</td>
                <td>{prod.regDate}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {totalPages > 1 && (
        <nav style={{ marginTop: '1rem' }}>
          <ul className="pagination" style={{ display: 'flex', listStyle: 'none', padding: 0, gap: '0.5rem' }}>
            {pageNumbers.map((num) => (
              <li key={num} style={{ cursor: 'pointer', padding: '0.3rem 0.7rem', border: num === currentPage ? '2px solid #007bff' : '1px solid #ddd', borderRadius: '4px', userSelect: 'none' }}
                onClick={() => handlePageChange(num)}
              >
                {num}
              </li>
            ))}
          </ul>
        </nav>
      )}
    </div>
  );
};

export default ProductListPage;
