// src/pages/ProductUpdatePage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';

const ProductUpdatePage = () => {
  const { prodNo } = useParams();
  const navigate = useNavigate();

  const [product, setProduct] = useState({
    prodName: '',
    prodDetail: '',
    manuDate: '',
    price: '',
    fileName: '',
  });
  const [preview, setPreview] = useState('');
  const [uploadFile, setUploadFile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // 상품 불러오기
  useEffect(() => {
    const fetchProduct = async () => {
      setLoading(true);
      setError('');
      try {
        const res = await axios.get(`/product/json/updateProduct/${prodNo}`, { withCredentials: true });
        setProduct(res.data);
        setPreview(res.data.fileName ? `/images/${res.data.fileName}` : 'https://via.placeholder.com/180?text=No+Image');
      } catch (err) {
        setError('상품 정보를 불러오는데 실패했습니다.');
      } finally {
        setLoading(false);
      }
    };
    fetchProduct();
  }, [prodNo]);

  // 파일 미리보기 처리
  const handleFileChange = (e) => {
    const file = e.target.files[0];
    setUploadFile(file);
    if (file) {
      const reader = new FileReader();
      reader.onload = (evt) => setPreview(evt.target.result);
      reader.readAsDataURL(file);
    }
  };

  // 입력 값 변경 처리
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProduct((prev) => ({
      ...prev,
      [name]: value
    }));
  };

  // 수정 버튼 처리
  const handleUpdate = async (e) => {
    e.preventDefault();
    setError('');
    const formData = new FormData();
    formData.append('prodNo', prodNo);
    formData.append('prodName', product.prodName);
    formData.append('prodDetail', product.prodDetail);
    formData.append('manuDate', product.manuDate);
    formData.append('price', product.price);
    if (uploadFile) formData.append('uploadFile', uploadFile); // 실제 파일 업로드
    try {
      await axios.post('/product/json/updateProduct', formData, {
        headers: { 'Content-Type': 'multipart/form-data' },
        withCredentials: true
      });
      alert('상품이 수정되었습니다.');
      navigate(-1); // 뒤로가기
    } catch (err) {
      setError('상품 수정에 실패했습니다.');
    }
  };

  // 취소 버튼
  const handleCancel = () => navigate(-1);

  if (loading) return <div className="container"><p>로딩 중...</p></div>;
  if (error) return <div className="container"><p style={{ color: 'red' }}>{error}</p></div>;

  return (
    <div className="container" style={{ paddingTop: '50px', maxWidth: '600px' }}>
      <h2>상품 정보 수정</h2>
      <form onSubmit={handleUpdate} encType="multipart/form-data">
        <table className="table table-bordered">
          <tbody>
            <tr>
              <th>상품명</th>
              <td>
                <input
                  type="text"
                  name="prodName"
                  value={product.prodName || ''}
                  onChange={handleChange}
                  maxLength={50}
                  className="form-control"
                  required
                />
              </td>
            </tr>
            <tr>
              <th>상품상세정보</th>
              <td>
                <input
                  type="text"
                  name="prodDetail"
                  value={product.prodDetail || ''}
                  onChange={handleChange}
                  maxLength={50}
                  className="form-control"
                  required
                />
              </td>
            </tr>
            <tr>
              <th>제조일자</th>
              <td>
                <input
                  type="text"
                  name="manuDate"
                  value={product.manuDate || ''}
                  onChange={handleChange}
                  maxLength={100}
                  className="form-control"
                  required
                />
              </td>
            </tr>
            <tr>
              <th>가격</th>
              <td>
                <input
                  type="number"
                  name="price"
                  value={product.price || ''}
                  onChange={handleChange}
                  maxLength={100}
                  className="form-control"
                  required
                />
              </td>
            </tr>
            <tr>
              <th>상품이미지</th>
              <td>
                <img
                  id="imgPreview"
                  className="preview-img"
                  src={preview}
                  alt="상품 미리보기"
                  style={{ maxWidth: '180px', maxHeight: '180px', border:'1px solid #ccc', marginBottom:'8px' }}
                /><br />
                <input
                  type="file"
                  name="uploadFile"
                  accept="image/*"
                  onChange={handleFileChange}
                  style={{ marginBottom: '6px' }}
                /><br />
                <small>{product.fileName}</small>
              </td>
            </tr>
          </tbody>
        </table>
        <div style={{ textAlign: 'right', marginTop: '20px' }}>
          <button type="submit" id="btnUpdate" className="btn btn-warning" style={{ marginRight: '8px' }}>
            수정
          </button>
          <button type="button" id="btnCancel" className="btn btn-secondary" onClick={handleCancel}>
            취소
          </button>
        </div>
      </form>
    </div>
  );
};

export default ProductUpdatePage;
